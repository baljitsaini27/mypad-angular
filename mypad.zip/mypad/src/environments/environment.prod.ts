export const environment = {
  production: true,
  apiUrl: 'http://api.cognitivegenerationenterprises.com/api/',
  pageSize: 10,
  pageNumber : 1,
};
