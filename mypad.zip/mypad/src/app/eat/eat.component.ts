import { Component, OnInit } from '@angular/core';
import { EatService } from '../eat/eat.service';
import { FormControl, FormGroup, Validators } from '@angular/forms'; 
import {Router} from '@angular/router';

@Component({
  selector: 'app-eat',
  templateUrl: './eat.component.html',
  styleUrls: ['./eat.component.css']
})
export class EatComponent implements OnInit {


  weighInForm = new FormGroup({
    txtWeight: new FormControl('',Validators.required) 
  });

  onSubmit() {  
    //debugger;
    if (this.weighInForm.invalid) {
      //return;
      //this.router.navigate(['Activity']);
    }
    else{ 
      console.warn(this.weighInForm.value); 

      var mealObj = {
        JISVJIALRAVL: true,
        MealName: 1,
        StartTime: null,
        EndTime: null,
        Weight: this.weighInForm.value.txtWeight,
        MealItem: {
          MealItemId: 1,
          MealItemName: "Meal"
        },
        UserName: "docgreenrob"
      };

      this.postmealEntry(mealObj);
      this.router.navigate(['Activity']);
      //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.weighInForm.value, null, 4));

    }  
  }

  constructor(private router: Router, private eatService: EatService) { }

  private currentItems  = [];  
  
  ngOnInit() {
    this.getMealCurrentItems();
  }

  getMealCurrentItems(){ 
    this.eatService.getMealCurrentItems().subscribe((res : any[])=>{  
      this.currentItems = res;   
     }); 
   }

   getMealEnd(){ 
    this.eatService.getMealEnd().subscribe((res : any[])=>{  
      this.currentItems = res;   
     }); 
   }
   
   postmealEntry(mealdetail){  
    this.eatService.postmealEntry(mealdetail).subscribe((res : any[])=>{        
      console.log(res); 
    });
  } 

}
