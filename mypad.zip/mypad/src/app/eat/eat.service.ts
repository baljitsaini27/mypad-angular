import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { environment } from "../../environments/environment";

@Injectable({
  providedIn: 'root'
})

export class EatService {

  constructor(private http : HttpClient) { }
 
  MealCurrentItemsApiUrl = environment.apiUrl + "meal/getCurrentItems/" + "docgreenrob";    
  mealEntryApiUrl = environment.apiUrl + "meal/mealEntry";    
  mealEndApiUrl = environment.apiUrl + "meal/end/" + "docgreenrob";
  
  getMealCurrentItems() {
    return this.http.get(this.MealCurrentItemsApiUrl); 
  } 
  getMealEnd() {
    return this.http.get(this.mealEndApiUrl); 
  } 
  postmealEntry(body){ 
    return this.http.post(this.mealEntryApiUrl, body); 
  }
 
}
