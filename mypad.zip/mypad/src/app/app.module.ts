import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core'; 
import { NgxPaginationModule } from 'ngx-pagination';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';  
import { ActivityComponent } from './activity/activity.component';
import { PhyiscalActivityComponent } from './phyiscal-activity/phyiscal-activity.component'; 
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { EatComponent } from './eat/eat.component';
import { WeighInComponent } from './weigh-in/weigh-in.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { NoteComponent } from './note/note.component';
import { WorkoutComponent } from './workout/workout.component';
import { HeaderNavComponent } from './header-nav/header-nav.component';
import { LeftSideBarComponent } from './left-side-bar/left-side-bar.component';
import { HomeComponent } from './home/home.component';  
import { AuthInterceptor } from './helpers/auth.interceptor';
import { ErrorInterceptor } from './helpers/error.interceptor';
import { LoginComponent } from './login/login.component'; 


@NgModule({
  declarations: [
    AppComponent, 
    ActivityComponent, 
    PhyiscalActivityComponent, 
    EatComponent, 
    WeighInComponent, 
    NoteComponent, 
    WorkoutComponent, 
    HeaderNavComponent, 
    LeftSideBarComponent, 
    HomeComponent, 
    LoginComponent 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgxPaginationModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
  ],
  bootstrap: [AppComponent] 
})
export class AppModule { }
