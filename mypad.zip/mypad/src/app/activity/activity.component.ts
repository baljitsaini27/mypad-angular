import { Component, OnInit } from '@angular/core';
import { ActivityService } from '../activity/activity.service';
import {ActivatedRoute, Router} from "@angular/router";
import { environment } from "../../environments/environment";

@Component({
  selector: 'app-activity',
  templateUrl: './activity.component.html',
  styleUrls: ['./activity.component.css']
})
export class ActivityComponent implements OnInit {
  private activityFeed  = [];  
  private openActivity  = "";  
  private exercise = [];
  private lastMeal = []; 
  config: any;

  constructor(private activityService: ActivityService, private router: Router) { 
    this.config = {
      currentPage: environment.pageNumber,
      itemsPerPage: environment.pageSize,
      totalItems:200
    }; 
  }

  ngOnInit() {     
    this.getOpenActivity();
    this.getActivityFeed();
  } 

  getActivityFeed(){ 
   this.activityService.getActivityFeed(1).subscribe((res : any[])=>{  
     this.activityFeed = res;  
    }); 
  }   

  getOpenActivity(){ 
    this.activityService.getOpenActivity().subscribe((res : string)=>{  
      this.openActivity = res;
      // if(res == 'Meal')
      // {        
      //   this.router.navigate(['/Eat'])
      // }
      // else{
      //   this.getActivityFeed();
      // }

     }); 
   }
   
   redoExercise(exerciseId){ 
    this.activityService.redoExercise(exerciseId).subscribe((res : any[])=>{  
      this.exercise = res; 
    }); 
  } 

  getLastMeal(){
    this.activityService.getLastMeal().subscribe((res : any[])=>{  
      this.lastMeal = res; 
    }); 
  }  

 pageChange(newPage: number) { 
    this.config.currentPage = newPage;
    
    this.activityService.getActivityFeed(newPage).subscribe((res : any[])=>{  
        this.activityFeed = res;  
    });    
 }  

}
