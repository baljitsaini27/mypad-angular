import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { observable } from 'rxjs';
import { environment } from "../../environments/environment";

@Injectable({
  providedIn: 'root'
})
export class ActivityService {

  constructor(private http : HttpClient) {   }
 
  ActivityFeedApiUrl = environment.apiUrl + "activity/getFeed/"  +"docgreenrob/";
  OpenActivityApiUrl = environment.apiUrl + "activity/getOpenActivity2/" + "docgreenrob";    
  exerciseApiUrl = environment.apiUrl + "exercise/"; 
  lastMealApiUrl = environment.apiUrl + "meal/getLastMeal/" + "docgreenrob"; 

 
  getActivityFeed(pagenumber) {
    return this.http.get(this.ActivityFeedApiUrl + pagenumber + "/10"); 
  }  
  getOpenActivity() {
    return this.http.get(this.OpenActivityApiUrl); 
  } 
  redoExercise(exerciseId){
    debugger;
    return this.http.get(this.exerciseApiUrl + exerciseId); 
  }  
  getLastMeal(){
    return this.http.get(this.lastMealApiUrl); 
  } 
  
}
