import { TestBed } from '@angular/core/testing';

import { WeighInService } from './weigh-in.service';

describe('WeighInService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WeighInService = TestBed.get(WeighInService);
    expect(service).toBeTruthy();
  });
});
