import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {WeighInService} from './weigh-in.service';
import {Router} from '@angular/router';
@Component({
  selector: 'app-weigh-in',
  templateUrl: './weigh-in.component.html',
  styleUrls: ['./weigh-in.component.css']
})
export class WeighInComponent implements OnInit {


  weighInForm = new FormGroup({
    txtWeight: new FormControl('',Validators.required) 
  });

  onSubmit() {  
    //debugger;
    if (this.weighInForm.invalid) {
      //return;
      //this.router.navigate(['Activity']);
    }
    else{ 
      console.warn(this.weighInForm.value); 
      var weigh = 
      { 
        JISVJIALRAVL: true,
        UserName: "docgreenrob",
        WeighIn: null, 
        Weight: this.weighInForm.value.txtWeight 
      }
      this.postWeigh(weigh);
      this.router.navigate(['Activity']);
      //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.weighInForm.value, null, 4));

    }  
  }
  constructor(private router: Router, private weighInService: WeighInService) { }

  ngOnInit() {
  }

  postWeigh(weighdetail){  
    this.weighInService.postWeigh(weighdetail).subscribe((res : any[])=>{        
      console.log(res); 
    });
  }  
}
