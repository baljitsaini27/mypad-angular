import { Component, OnInit } from '@angular/core';
import {WorkoutService} from './workout.service';
import {Router} from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-workout',
  templateUrl: './workout.component.html',
  styleUrls: ['./workout.component.css']
})


export class WorkoutComponent implements OnInit {
 
  constructor(private router: Router, private workoutService: WorkoutService) { }

  private physicalEntryExercise = [];
  private bodyPartHistory = []; 
  
  ngOnInit() {
  }

  workoutForm = new FormGroup({
    txtReps: new FormControl('',Validators.required), 
    txtWeight: new FormControl('',Validators.required) 
  });
  
  onSubmit() {

    var objectToPost = {
      JISVJIALRAVL: true,
      BodyPart: null,
      Distance: null,
      Duration: null,
      EndTimeString: null,
      ExerciseName: null,
      Id: 1,
      Reps: this.workoutForm.value.txtReps,
      Weight: this.workoutForm.value.txtWeight,
      StartTimeString: null,
      Type: null,
      WorkoutName: null,
      UserName: 'docgreenrob'
    };

   this.postPhysicalEntry(objectToPost);

  }
  
  postPhysicalEntry(physicalEntrydetail){ 
    this.workoutService.postPhysicalEntry(physicalEntrydetail).subscribe((res : any[])=>{        
      console.log(res);  
    });
  }   
  getRandomPhysicalEntryExercise(){ 
    this.workoutService.getRandomPhysicalEntryExercise().subscribe((res : any[])=>{  
      this.physicalEntryExercise = res;   
      this.getBodyPartHistory(res["BodyPart"]);
     }); 
   } 
   getBodyPartHistory(bodyPart){ 
     
    this.workoutService.getBodyPartHistory(bodyPart).subscribe((res : any[])=>{  
      this.bodyPartHistory = res;   
     }); 
   }
   getBodyPartWorkouts(){ 
    this.workoutService.getBodyPartWorkouts().subscribe((res : any[])=>{  
      this.physicalEntryExercise = res;  
     }); 
   }
   getBodyPartExercises(){ 
    this.workoutService.getBodyPartExercises().subscribe((res : any[])=>{  
      this.physicalEntryExercise = res;  
     }); 
   }
   getBodyPartOverview(){ 
    this.workoutService.getBodyPartOverview().subscribe((res : any[])=>{  
      this.physicalEntryExercise = res;  
     }); 
   }
   getBodyPartOverviewExcludeToday(){ 
    this.workoutService.getBodyPartOverviewExcludeToday().subscribe((res : any[])=>{  
      this.physicalEntryExercise = res;  
     }); 
   }   
}
