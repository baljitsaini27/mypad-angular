import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class WorkoutService {

  constructor(private http : HttpClient) { }

  physicalEntryApiUrl = "http://api.cognitivegenerationenterprises.com/api/physicalEntry/end";    
  physicalEntryExerciseApiUrl = "http://api.cognitivegenerationenterprises.com/api/physicalEntry/getRandomPhysicalEntryExercise";
  bodyPartHistoryApiUrl = "http://api.cognitivegenerationenterprises.com/api/exercise/getBodyPartHistory/docgreenrob/";
  bodyPartWorkoutsApiUrl = "http://api.cognitivegenerationenterprises.com/api/workout/getBodyPartWorkouts/";
  bodyPartExercisesApiUrl = "http://api.cognitivegenerationenterprises.com/api/workout/getBodyPartExercises/";
  bodyPartOverviewApiUrl = "http://api.cognitivegenerationenterprises.com/api/physicalEntry/getBodyPartOverview/";
  bodyPartOverviewExcludeTodayApiUrl = "http://api.cognitivegenerationenterprises.com/api/physicalEntry/GetBodyPartOverviewExcludeToday/";

  postPhysicalEntry(body){  
    return this.http.post(this.physicalEntryApiUrl, body); 
  }
  getRandomPhysicalEntryExercise(){  
    return this.http.get(this.physicalEntryExerciseApiUrl);  
  }
  getBodyPartHistory(bodyPart){  
    return this.http.get(this.bodyPartHistoryApiUrl + bodyPart);  
  }
  getBodyPartWorkouts(){  
    return this.http.get(this.bodyPartWorkoutsApiUrl); 
  }
  getBodyPartExercises(){  
    return this.http.get(this.bodyPartExercisesApiUrl); 
  }
  getBodyPartOverview(){  
    return this.http.get(this.bodyPartOverviewApiUrl); 
  }
  getBodyPartOverviewExcludeToday(){  
    return this.http.get(this.bodyPartOverviewExcludeTodayApiUrl); 
  }

}
