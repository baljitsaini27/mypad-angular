import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PhyiscalActivityService {

  constructor(private http : HttpClient) { }

  PhyiscalActivityApiUrl = "http://api.cognitivegenerationenterprises.com/api/physicalEntry/end";    
  
  postPhyiscalActivity(body){  
    debugger;
    return this.http.post(this.PhyiscalActivityApiUrl, body); 
  }
}
