import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {PhyiscalActivityService} from './phyiscal-activity.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-phyiscal-activity',
  templateUrl: './phyiscal-activity.component.html',
  styleUrls: ['./phyiscal-activity.component.css']
})
export class PhyiscalActivityComponent implements OnInit {

  phyiscalActivityDistanceForm = new FormGroup({
    txtDistance: new FormControl('',Validators.required) 
  });

  phyiscalActivityRepsForm = new FormGroup({
    txtReps: new FormControl('',Validators.required) 
  });

  onSubmitDistance() {  
    //debugger;
    if (this.phyiscalActivityDistanceForm.invalid) {
      //return;
      //this.router.navigate(['Activity']);
    }
    else{ 
      console.warn(this.phyiscalActivityDistanceForm.value); 
      var phyiscalActivity = 
      { 
        JISVJIALRAVL: true,
			  Distance: this.phyiscalActivityDistanceForm.value.txtDistance,
			  Type: 'jog',
			  Id: 1,
        UserName: "docgreenrob" 
      }
      this.postPhyiscalActivity(phyiscalActivity);
      this.router.navigate(['Activity']);
      //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.phyiscalActivityForm.value, null, 4));

    }  
  }

  onSubmitReps() {  
    //debugger;
    if (this.phyiscalActivityRepsForm.invalid) {
      //return;
      //this.router.navigate(['Activity']);
    }
    else{ 
      console.warn(this.phyiscalActivityRepsForm.value); 
      var phyiscalActivity = 
      { 
        JISVJIALRAVL: true,
			  Distance: this.phyiscalActivityRepsForm.value.txtReps,
			  Type: 'jog',
			  Id: 1,
        UserName: "docgreenrob" 
      }
      this.postPhyiscalActivity(phyiscalActivity);
      this.router.navigate(['Activity']);
      //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.phyiscalActivityRepsForm.value, null, 4));

    }  
  }

  constructor(private router: Router, private phyiscalActivity: PhyiscalActivityService) { }

  ngOnInit() {
  }

  postPhyiscalActivity(phyiscalActivitydetail){  
    this.phyiscalActivity.postPhyiscalActivity(phyiscalActivitydetail).subscribe((res : any[])=>{        
      console.log(res);   
    });
  }

}
