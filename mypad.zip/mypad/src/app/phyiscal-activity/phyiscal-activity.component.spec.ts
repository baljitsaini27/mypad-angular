import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PhyiscalActivityComponent } from './phyiscal-activity.component';

describe('PhyiscalActivityComponent', () => {
  let component: PhyiscalActivityComponent;
  let fixture: ComponentFixture<PhyiscalActivityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PhyiscalActivityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhyiscalActivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
