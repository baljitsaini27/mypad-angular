import { TestBed } from '@angular/core/testing';

import { PhyiscalActivityService } from './phyiscal-activity.service';

describe('PhyiscalActivityService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PhyiscalActivityService = TestBed.get(PhyiscalActivityService);
    expect(service).toBeTruthy();
  });
});
