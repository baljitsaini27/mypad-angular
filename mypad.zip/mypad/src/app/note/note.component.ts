import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {NoteService} from './note.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-note',
  templateUrl: './note.component.html',
  styleUrls: ['./note.component.css']
})
export class NoteComponent implements OnInit {

  noteForm = new FormGroup({
    txtSubject: new FormControl('',Validators.required), 
    txtContent: new FormControl('',Validators.required) 
  });

  onSubmit() {  
    //debugger;
    if (this.noteForm.invalid) {
      //return;
      //this.router.navigate(['Activity']);
    }
    else{ 
      console.warn(this.noteForm.value); 
      var note = 
      { 
        JISVJIALRAVL: true,
        UserName: "docgreenrob",
        Contents: this.noteForm.value.txtSubject,
				Subject: this.noteForm.value.txtContent 
      }
      this.postNote(note);
      this.router.navigate(['Activity']);
      //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.noteForm.value, null, 4));

    }  
  }

  constructor(private router: Router, private noteService: NoteService) { }

  ngOnInit() {
  }

  postNote(notedetail){  
    this.noteService.postNote(notedetail).subscribe((res : any[])=>{        
      console.log(res);  
    });
  }

}
