import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class NoteService {

  constructor(private http : HttpClient) { }

  NoteApiUrl = "http://api.cognitivegenerationenterprises.com/api/note";    
  
  postNote(body){  
    return this.http.post(this.NoteApiUrl, body); 
  }
}
