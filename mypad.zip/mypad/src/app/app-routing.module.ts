import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router'; 
import { ActivityComponent } from './activity/activity.component';
import { PhyiscalActivityComponent } from './phyiscal-activity/phyiscal-activity.component'; 
import { EatComponent } from './eat/eat.component';
import { WeighInComponent } from './weigh-in/weigh-in.component';
import { NoteComponent } from './note/note.component';
import { WorkoutComponent } from './workout/workout.component';
import { from } from 'rxjs';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component'; 
import { AuthGuard } from './Helpers/auth.guard';
import { LoginComponent } from './login/login.component'; 

const routes: Routes = [
  {path: '', component:HomeComponent, canActivate: [AuthGuard]},
  {path: 'Home', component:HomeComponent, canActivate: [AuthGuard]},
  { path: 'PhyiscalActivity', component: PhyiscalActivityComponent, canActivate: [AuthGuard] },
  { path: 'Activity', component: ActivityComponent, canActivate: [AuthGuard]},
  { path: 'Eat', component: EatComponent, canActivate: [AuthGuard] }, 
  { path: 'WeighIn', component: WeighInComponent, canActivate: [AuthGuard] },
  { path: 'Note', component: NoteComponent, canActivate: [AuthGuard] },
  { path: 'Workout', component: WorkoutComponent, canActivate: [AuthGuard] } ,
  { path: 'login', component: LoginComponent} 
];

@NgModule({
  imports: [RouterModule.forRoot(
    routes
   // <-- debugging purposes only
    )],
  exports: [RouterModule]
})
export class AppRoutingModule { }
