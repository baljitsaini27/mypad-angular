'use strict';

// START_CUSTOM_CODE_meals
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function () {
	app.data.meals = {
		url: 'http://api.cognitivegenerationenterprises.com/api/mealItem/' + app.userSettings.UserName
	}
}());

// END_CUSTOM_CODE_meals