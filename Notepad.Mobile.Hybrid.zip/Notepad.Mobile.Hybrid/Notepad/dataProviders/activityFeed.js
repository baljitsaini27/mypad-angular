'use strict';

// START_CUSTOM_CODE_activityFeed
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function () {
	app.data.activityFeed = {
		url: 'http://api.cognitivegenerationenterprises.com/api/activity/getFeed/' + app.userSettings.UserName + '/0/500'
	}
}());

// END_CUSTOM_CODE_activityFeed