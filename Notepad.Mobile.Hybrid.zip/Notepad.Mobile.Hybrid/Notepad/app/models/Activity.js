/* Activity */
var Activity = function () {
	this.getFeed = function () {
		var notepad = Singleton.getInstance('Notepad');

		// get feed
		var apiMethod = '/activity/getFeed/' + app.userSettings.UserName + '/0/500';

		notepad.utils.http.ajaxGet(notepad.domain + apiMethod, function (response) {
			//alert('success');
		}, function (error) {
			alert('error');
		});
	}
};