/* Notepad */
var Notepad = function () {
	this.device = {
		camera: function (onSuccess, onError) {
			app.utils.uploadFile('camera');
		}
	};
	this.domain = 'http://api.cognitivegenerationenterprises.com/api';
	this.utils = {
		cleanArray: function (array) {
			if (array.length < 3)
				return array; // its only a pair, no need to compare

			var newArray = [];
			var tempCleanArray = [];

			// compare id's
			// this was originally built for app.home.homeObj.icons - 12.28.16
			var currentId = array[0].Property;

			// put the first element in the array
			newArray.push({
				Html: array[0].Html,
				Property: currentId,
				Type: array[0].Type
			});

			// check if the second one is in the array
			// then compare to every nth element in the array
			for (var j = 1; j < array.length; j++) {
				if (currentId != array[j].Property) {
					tempCleanArray.push({
						Html: array[j].Html,
						Property: array[j].Property,
						Type: array[j].Type
					});
				}
			}

			// tempCleanArray holds all values from array not equal to array[0] and not a duplicate of array[0]

			if (tempCleanArray.length > 0) {
				do {
					// so let's add it to the result array
					newArray.push({
						Html: tempCleanArray[0].Html,
						Property: tempCleanArray[0].Property,
						Type: tempCleanArray[0].Type
					});

					currentId = tempCleanArray[0].Property;
					array = tempCleanArray;
					tempCleanArray = [];
					for (var j = 1; j <= array.length - 1; j++) {
						if (currentId != array[j].Property) {
							tempCleanArray.push({
								Html: array[j].Html,
								Property: array[j].Property,
								Type: array[j].Type
							});
						}
					}
				} while (tempCleanArray.length > 0)
			}

			return newArray;
		},
		convertArrayToStringArray: function (array, delimeter) {
			return array.join(delimeter);
		},
		convertEMtoPixels: function (value) {
			return value * app.utils.getRootElementFontSize();
		},
		convertStringToArray: function (val) {
			throw new Error('Implement');
		},
		getDateDiff: function (date1, date2, interval) {
			var second = 1000,
			minute = second * 60,
			hour = minute * 60,
			day = hour * 24,
			week = day * 7;
			date1 = new Date(date1).getTime();
			date2 = (date2 == 'now') ? new Date().getTime() : new Date(date2).getTime();
			var timediff = date2 - date1;
			if (isNaN(timediff)) return NaN;
			switch (interval) {
				case "years":
					return date2.getFullYear() - date1.getFullYear();
				case "months":
					return ((date2.getFullYear() * 12 + date2.getMonth()) - (date1.getFullYear() * 12 + date1.getMonth()));
				case "weeks":
					return Math.floor(timediff / week);
				case "days":
					return Math.floor(timediff / day);
				case "hours":
					return Math.floor(timediff / hour);
				case "minutes":
					return Math.floor(timediff / minute);
				case "seconds":
					return Math.floor(timediff / second);
				default:
					return undefined;
			}
		},
		getMax: function (obj1, obj2) {
			if (obj1.length > obj2.length)
				// 1 > 2
				return obj1;
			else {
				if (obj1.length < obj2.length) {
					// 2 > 1
					return obj2;
				}
			}
			// equal
			return obj2;
		},
		getProperCase: function (val) {
			var strVal = '';
			var str = val.split();
			for (var chr = 0; chr < str.length; chr++) {
				strVal += str[chr].substring(0, 1).toUpperCase() + str[chr].substring(1, str[chr].length) + ' ';
			}
			return strVal.trim();
		},
		getTicks: function () {
			return ((new Date().getTime() * 10000) + 621355968000000000);
		},
		history: {
			add: function (type, id, text, lineItem) {
				// old
				app.my.myObj.State.Views.History.push({ Type: type, Id: id, Text: text });

				// new
				var history = Singleton.getInstance('History');
				history.add(type, text, id, lineItem);
			},
			get: function () { }
		},
		http: {
			ajaxGet: function (url, onSuccess, onError) {
				$.ajax({
					url: url,
					type: 'GET',
					success: function (response) {
						onSuccess(response);
					},
					error: function (error) {
						onError(error);
					}
				});
			},
			ajaxPost: function (url, obj, onSuccess, onError) {
				var json = JSON.stringify(obj);

				$.ajax({
					url: url,
					type: 'POST',
					contentType: 'application/json; charset=utf-8',
					data: json,
					dataType: 'json',
					success: function (response) {
						onSuccess(response);
					},
					error: function (error) {
						onError(error);
					}
				});
			},
			getParent: {
				lineItemType: function (lineItemTypeId, onSuccess, onError) {
					throw new Error('Implement');
				}
			},
			getUPC: function (upc, onSuccess, onError) {
				var url = app.domain + '/upc/' + upc;
				app.utils.http.ajaxGet(url, onSuccess, onError);
			},
		},
		isInArray: function (array, value) {

			if (typeof value === typeof {}) {
				for (var i = 0; i < array.length; i++) {
					if (array[i].Id == value.Id) {
						return true;
					}
				}
				return false;
			}

			for (var j = 0; j < array.length; j++) {
				if (value.toLowerCase() == array[j].toLowerCase())
					return true;
			}

			return false;
		},
		log: function (val, split) {
			// newLine (split)
			if (Array.isArray(val)) {
				var output = '';

				// [x,y,z]

				for (var i = 0; i < val.length; i++) {
					output += val[i] + ': ' + val[i] + ' ';
					if (split)
						output += '\n';
				}

				console.log(output);
				return;

				// [{Key: 'x', Value: 'x1'},{Key: 'y', Value: 'y1'},{Key: 'z', Value: 'z1'}

				for (var j = 0; j < val.length; j++) {
					output += val[j].Key + ': ' + val[j].Value + ' ';
					if (split) {
						output += '\n';
					}
				}

				console.log(output);
			}
		},
		logError: function (file, errorMsg) {
			console.log('Error **********************\n File: (' + file + ') \n Mssg: ' + errorMsg);
		},
		notNullOrZero: function (val) {
			if (val == undefined)
				return false;
			if (val == 'undefined')
				return false;
			if (val == null)
				return false;
			if (val == 'null')
				return false;
			if (val == '0')
				return false;
			if (val == '00')
				return false;
			if (val == 0)
				return false;
			return true;
		},
		objects: {
			getCompanyType: function (userType) {
				for (var i = 0; i < app.my.myObj.CompanyTypes.length; i++) {
					if (app.my.myObj.CompanyTypes[i].Name.toLowerCase().indexOf(userType) != -1) {
						return app.my.myObj.CompanyTypes[i];
					}
				}
			},
			getUserType: function (userType) {
				for (var i = 0; i < app.userSettings.UserTypes.length; i++) {
					if (app.userSettings.UserTypes[i].Name.toLowerCase().indexOf(userType) != -1) {
						return app.userSettings.UserTypes[i];
					}
				}
			},
			findArea: function (area, onSuccess, onError) {
				app.utils.http.ajaxGet(app.domain + '/area/getArea/' + area, function (response) {
					onSuccess(response);
				}, function (error) {
					onError(error);
				});
			}
		},
		removeFromArray: function (array, value) {
			var newArray = [];
			if (app.utils.isInArray(array, value)) {
				for (var i = 0; i < array.length; i++) {
					// if is an obj
					if (typeof value === typeof {} && typeof array[i] === typeof {}) {
						if (array[i].Id != value.Id)
							newArray.push(value);
					} else {
						// if not an obj (i.e., string, int ok)
						if (value != array[i])
							newArray.push(value);
					}

				}
				return newArray;
			}
			//throw new Error('Value not in array!');
		},
		ui: {
			toast: function (msg, callback) {
				if (!app.checkSimulator()) {
					window.plugins.toast.showShortCenter(msg, function (e) {
						callback();
					}, function (msg) {
						alert('Toast error: ' + msg);
					});
				}
			},
			hideMenu: function () {
				$('.km-tabstrip').css('display', 'none');
			},
			showMenu: function () {
				$('.km-tabstrip').css('display', 'block');
			},
			showModal: function ($domElement, obj, title, text, options) {
				$('.modalTitle').html('');
				$('.modalTitle').html(title);
				$('.modalText').html('');
				$('.modalText').html(text);

				for (var i = 0; i < options.length; i++) {
					$('.app_ModalView').css(options[i][0], options[i][1]);
				}
				$domElement.data("kendoMobileModalView").open();
				kendo.bind($domElement, obj, kendo.mobile.ui);
			},
			hideModal: function ($domElement, obj) {
				$domElement.data("kendoMobileModalView").close();
				kendo.bind($domElement, obj, kendo.mobile.ui);
			},
			hideFooterButton: function () {
				$('.floating').css('background-image', 'none');
				$('.floating').css('border-color', 'transparent');
			},
			showFooterButton: function (callback) {

				$('.floating').css('border-color', '');
				$('.floating').css('background-image', 'url("' + buttonPath + '")');

				$('.floating').click(function () {
					app.mobileApp.showLoading();
					callback();
				});

			},
		},
		uploadFile: function (type, onSuccess, onError) {
			// housekeeping
			var fileOptions = {};
			var errorOutput = null;

			switch (type) {
				case 'digiDoc':
					errorOutput = app.digidoc.ui.render.message("Uploading DigiDoc...");
					fileOptions = {
						quality: 100,
						destinationType: navigator.camera.DestinationType.FILE_URI,
						sourceType: navigator.camera.PictureSourceType.PHOTOLIBRARY,
						mediaType: navigator.camera.MediaType.ALLMEDIA
					};
					break;
				case 'camera':
					errorOutput = app.digidoc.ui.render.message("Uploading Picture...");
					fileOptions = {
						quality: 100,
						destinationType: Camera.DestinationType.FILE_URI,
						sourceType: navigator.camera.PictureSourceType.CAMERA,
						encodingType: Camera.EncodingType.JPEG,
						targetWidth: 100,
						targetHeight: 100,
						popoverOptions: CameraPopoverOptions
					};
					break;
			}

			// open camera
			navigator.camera.getPicture( // success
				uploadPhoto,
			function (message) { // error
				if (type !== 'camera')
					errorOutput();
			}, // options
			fileOptions);

			function uploadPhoto(fileURI) {
				app.action.data.fileURI = fileURI;
				app.action.ui.handlers.complete.success({ kind: 'userFile', uri: app.action.data.fileURI });
			}
		},
		template: {
			action: function (onSuccess, onError) {
				app.utils.template.load("components/action/action.html", $('.div_main'), false, function (actionResponse) {
					onSuccess(actionResponse);
				}, function (actionError) {
					onError(actionError);
				});
			},
			areaManager: {
				load: function (onSuccess, onError) {
					app.utils.template.load("components/areaManager/areaManager.html", $('.container'), false, function (areaResponse) {
						onSuccess(areaResponse);
					}, function (areaError) {

					});
				}
			},
			assetNavigator: function (lineItemId, lineItemText) {
				app.utils.template.load("components/assetNavigator/assetNavigator.html", $('.div_main'), false, function (response) {
					// clear breadcrumbs first
					//app.carosuel.ui.elements.breadcrumbs.clear();

					// render breadcrumbs
					app.carosuel.ui.render.breadcrumb('lineItem', lineItemId, lineItemText);
					var history = Singleton.getInstance('History');
					var historyProfileItem = history.getLast('profileitem');

					// get assets
					app.assetNavigator.utils.http.handler.get.assets(app.my.myObj.SelectedIcon.Property, historyProfileItem.Id, lineItemId, function (response) {

						// hide loading
						console.log('hide loading');
						app.mobileApp.hideLoading();

						app.assetNavigator.init();
					}, function (error) { });
				}, function (error) {
					onError(error);
				});
			},
			assetViewer: function (onSuccess, onError) {
				app.utils.template.load("components/assetViewer/assetViewer.html", $('.div_main'), false, function (response) {
					onSuccess(response);
				}, function (error) {
					onError(error);
				});
			},
			load: function (path, $domElement, append, onSuccess, onError) {
				app.utils.http.ajaxGet(path, function (response) {
					if (append)
						$domElement.append(response);
					else
						$domElement.html(response);
					try {
						onSuccess(response);
					} catch (e) {

					}

				}, function (error) {
					onError(error);
				});
			},
			pathFinder: function (onSuccess, onError) {
				app.utils.template.load("components/pathFinder/pathFinder.html", $('.container'), false, function (pathFinderResponse) {
					onSuccess(pathFinderResponse);
				}, function (pathFinderError) {
					onError(pathFinderError);
				});
			},
			propertyOverview: {
				load: function (onSuccess, onError) {
					app.utils.template.load("components/propertyOverview/propertyOverview.html", $('.div_main'), false, function (propertyOverviewResponse) {
						// determine 1st icon
						var selectedIcon = app.home.homeObj.Icons[0];

						// init() property Overview component
						app.propertyOverview.init(selectedIcon.Type, selectedIcon.Property);
						onSuccess(propertyOverviewResponse);
					}, function (propertyOverviewError) {

					});
				}
			},
			shortlistManager: function (onSuccess, onError) {
				// remove div_carosuel
				app.home.ui.components.carosuel.remove();

				// remove div_main
				app.home.ui.components.div_main.removeAll();

				// remove action
				app.action.ui.hide();

				// remove action
				app.utils.template.load("components/shortlistManager/shortlistManager.html", $('.div_main'), false, function (response) {
					onSuccess(response);
				}, function (error) {
					onError(error);
				});
			}
		}
	};
	this.userSettings = {
		UserId: 0,
		UserName: '',
		Sounds: {
			railroad: null
		}
	};
	this.verify = function () {
		alert('Action Works: ' + type);
	}
};

var instanceArray = [];

// Singleton
var Singleton = (function () {
	var instance;

	function createInstance(type) {
		var object;

		switch (type) {
			case 'Activity':
				object = new Activity();
				instanceArray.push({ Type: 'Activity', Object: object });
				break;
			case 'Notepad':
				object = new Notepad();
				instanceArray.push({ Type: 'Notepad', Object: object });
				break;
		}

		return object;
	}

	function alreadyInstantiated(type) {
		for (var i = 0; i < instanceArray.length; i++) {
			if (instanceArray[i].Type === type)
				return true;
		}
		return false;
	}

	function returnInstance(type) {
		for (var i = 0; i < instanceArray.length; i++) {
			if (instanceArray[i].Type === type)
				return instanceArray[i].Object;
		}
	}

	return {
		getInstance: function (type) {
			if (!alreadyInstantiated(type)) {
				// first time for this type
				return createInstance(type);
			} else {
				// subsequent requests
				return returnInstance(type);
			}
		}
	};
})();