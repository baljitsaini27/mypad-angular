'use strict';

// START_CUSTOM_CODE_kendoUiMobileApp
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (global) {

	var hours, minutes, seconds, finalDisplay, incrementer, timer, page;

	var app = {
		page: '',
		data: {},
		userSettings: {
			UserName: '',
			Sounds: {
				railroad: null
			}
		},
		toast: function (msg, callback) {
			if (!app.checkSimulator()) {
				window.plugins.toast.showShortCenter(msg, function (e) {
					callback();
				}, function (msg) {
					alert('Toast error: ' + msg);
				});
			}
		},
		ajaxGet: function (url, onSuccess, onError) {
			$.ajax({
				url: url,
				type: 'GET',
				contentType: 'application/json; charset=utf-8',
				success: function (response) {
					// request success
					onSuccess(response);
				},
				error: function (error) {
					onError(error);;
				}
			});
		},
		ajaxPost: function (url, obj, onSuccess, onError) {
			var json = JSON.stringify(obj);

			$.ajax({
				url: url,
				type: 'POST',
				contentType: 'application/json; charset=utf-8',
				data: json,
				dataType: 'json',
				success: function (response) {
					onSuccess(response);
				},
				error: function (error) {
					onError(error);
				}
			});
		},
		tick: function () {
			timer++;
			app.updateDisplay();
			app.increment();

			if (app.page == 'timer') {
				$('.timerStopwatch').html(finalDisplay);
				kendo.bind($('.timerStopwatch'), app.workout, kendo.mobile.ui);
			}

			if (app.page == 'activityFeed') {
				$('#span_timer').html(finalDisplay);
				kendo.bind($('#span_timer'), app.activity, kendo.mobile.ui);
			}
		},
		updateDisplay: function () {
			//debugger;

			if (isNaN(timer))
				timer = 0;

			if (timer < 10) {
				app.globalProps.seconds = '0' + timer;
			} else {
				if (timer < 60) {
					app.globalProps.seconds = timer;
				} else {
					// timer is 60, minute change
					timer = 0; // test with 0
					app.globalProps.seconds = '00';

					console.log('increment minutes');
					// increment minutes
					var _minutes = Number(app.globalProps.minutes);
					if (_minutes < 60) {
						_minutes++;
						if (_minutes < 10) {
							app.globalProps.minutes = '0' + _minutes;
						} else {
							app.globalProps.minutes = _minutes;
						}
						console.log('Minutes: ' + app.globalProps.minutes);
					} else {
						console.log('increment hours');
						// increment hours
						minutes = '00';
						var _hours = Number(app.globalProps.hours);
						_hours++;
						if (_hours < 10) {
							app.globalProps.hours = '0' + _hours;
						} else {
							app.globalProps.hours = _hours;
						}
					}
				}
			}
			app.globalProps.minutes = (app.globalProps.minutes == undefined) ? '00' : app.globalProps.minutes;
			app.globalProps.hours = (app.globalProps.hours == undefined || isNaN(app.globalProps.hours)) ? '00' : app.globalProps.hours;
			console.log('hours: ' + app.globalProps.hours);
			finalDisplay = app.globalProps.hours + ':' + app.globalProps.minutes + ':' + app.globalProps.seconds;
			console.log(finalDisplay);
		},
		increment: function () {
			incrementer = setTimeout(app.tick, 1000);
		},
		endTimer: function () {
			clearTimeout(incrementer);
			app.globalProps.hours = '00';
			app.globalProps.minutes = '00';
			app.globalProps.seconds = '00';
			app.globalProps.finalDisplay = '';
			timer = 0;
		},
		currentView: function (view) {
			app.page = view;
		},
		setFinalDisplay: function (hours, minutes, seconds) {
			timer = seconds;
			app.globalProps.hours = hours.toString().length == 1 ? '0' + hours : hours;
			app.globalProps.minutes = minutes.toString().length == 1 ? '0' + minutes : minutes;
			app.globalProps.seconds = seconds.toString().length == 1 ? '0' + seconds : seconds;
			finalDisplay = app.globalProps.hours + ':' + app.globalProps.minutes + ':' + app.globalProps.seconds;
			app.tick();
		},
		globalProps: {
			hours: '00',
			minutes: '00',
			seconds: '00',
			finalDisplay: '00:00:00'
		},
		checkOpenActivity: function () {
			$.ajax({
				url: 'http://api.cognitivegenerationenterprises.com/api/activity/getOpenActivity2/' + app.userSettings.UserName,
				type: 'GET',
				contentType: 'application/json; charset=utf-8',
				success: function (response) {
					// request succeeded
					if (response == 'Meal') {
						app.eat.eatObj.eating = true;
						app.mobileApp.navigate("modules/eat/eatIndex.html");
					}
					/*
                    if (response == 'Exercise') {
                        app.mobileApp.navigate("modules/home/view.html#eat"");
                    }
                   */

				},
				error: function (error) {
					// request failed
					console.log('Get Open activity error: ' + error);
				}
			});
		},
		hideMenu: function () {
			$('.km-leftitem').css('display', 'none');
		},
		showMenu: function () {
			$('.km-leftitem').css('display', 'block');
		},
		notNullOrZero: function (val) {
			if (val == undefined)
				return false;
			if (val == 'undefined')
				return false;
			if (val == null)
				return false;
			if (val == 'null')
				return false;
			if (val == '0')
				return false;
			if (val == '00')
				return false;
			if (val == 0)
				return false;
			return true;
		},
		convertArrayToString: function (array, delimeter) {
			return array.join(delimeter);
		},
		convertStringToArray: function (val) {
			throw new Error('Implement');
		},
		hideFooterButton: function () {
			$('.floating').css('background-image', 'none');
			$('.floating').css('border-color', 'transparent');
		},
		hideFooterButtons: function () {
			$('.floating').css('background-image', 'none');
			$('.floating').css('border-color', 'transparent');
			$('.floating').parent().find('.footerButtonExtra').remove();
			// solution = display:none
		},
		showFooterButton: function (buttonPath, callback) {

			$('.floating').css('border-color', '');
			$('.floating').css('background-image', 'url("' + buttonPath + '")');

			$('.floating').click(function () {
				app.mobileApp.showLoading();
				callback();
			});

		},
		showFooterButtons: function (array) {

			$('.floating').css('border-color', '');

			for (var i = 0; i < array.length; i++) {

				var pixels = app.convertEMtoPixels(3);
				var right = 10 + (i * pixels) + (i * 10);

				array[i].buttonPathRaw = array[i].buttonPath;
				app.footerButtonCallbackArray.push(array[i]);

				if (i == 0) {
					$('.floating').css('background-image', 'url("' + array[i].buttonPath + '")');

					$('.floating').click(function () {

						var img = $(this).css('background-image');

						for (var i = 0; i < app.footerButtonCallbackArray.length; i++) {
							if (img.indexOf(app.footerButtonCallbackArray[i].buttonPathRaw) != -1) {
								app.footerButtonCallbackArray[i].callback();
							}
						}

					});
				} else {

					var $newButton = $('.floating').clone();

					// change background-url and border-color
					$newButton.css('background-image', 'url("' + array[i].buttonPath + '")');

					// set right offset
					$newButton.css('right', right + 'px');

					$newButton.addClass(' footerButtonExtra');

					// add event listener
					$newButton.click(function () {
						var img = $(this).css('background-image');

						for (var i = 0; i < app.footerButtonCallbackArray.length; i++) {
							if (img.indexOf(app.footerButtonCallbackArray[i].buttonPathRaw) != -1) {
								app.footerButtonCallbackArray[i].callback();
							}
						}

						$(this).parent().find('.footerButtonExtra').remove();
					});

					// append
					$('.dom_footer').append($newButton);
				}
			}

		},
		convertEMtoPixels: function (value) {
			return value * app.getRootElementFontSize();
		},
		footerButtonCallbackArray: [],
		getDateDiff: function (date1, date2, interval) {
			var second = 1000,
            minute = second * 60,
            hour = minute * 60,
            day = hour * 24,
            week = day * 7;
			date1 = new Date(date1).getTime();
			date2 = (date2 == 'now') ? new Date().getTime() : new Date(date2).getTime();
			var timediff = date2 - date1;
			if (isNaN(timediff)) return NaN;
			switch (interval) {
				case "years":
					return date2.getFullYear() - date1.getFullYear();
				case "months":
					return ((date2.getFullYear() * 12 + date2.getMonth()) - (date1.getFullYear() * 12 + date1.getMonth()));
				case "weeks":
					return Math.floor(timediff / week);
				case "days":
					return Math.floor(timediff / day);
				case "hours":
					return Math.floor(timediff / hour);
				case "minutes":
					return Math.floor(timediff / minute);
				case "seconds":
					return Math.floor(timediff / second);
				default:
					return undefined;
			}
		}
	};

	var bootstrap = function () {

		$(function () {

			app.mobileApp = new kendo.mobile.Application(document.body, {
				skin: 'nova',
				initial: 'modules/home/homeIndex.html'
			});

			// so the button doesn't display on load (at the login page)
			app.hideFooterButton();

			// anytime a navigation menu item is clicked, hide the footer button(s)
			$("#navigation-container").bind('mouseup', function () {
				console.log('link clicked');
				app.hideFooterButton();
			});

		});

	};

	if (window.cordova) {
		document.addEventListener('deviceready', function () {

			app.userSettings.Sounds.reminder = device.platform == 'Android' ? 'file://railroad_crossing_bell.mp3' : 'file://beep.caf';

			app.clearAllNotifications = function () {
				if (!app.checkSimulator()) {
					window.plugin.notification.local.getScheduledIds(function (scheduledIds) {
						for (var i = 0; scheduledIds.length > i; i++) {
							window.plugin.notification.local.cancel(scheduledIds[i]);
							// Notifications cancelled
							app.toast('Notification ' + scheduledIds[i] + ' cancelled', null);
						}
					});
				}
			};

			if (navigator && navigator.splashscreen) {
				navigator.splashscreen.hide();
			}

			var element = document.getElementById('appDrawer');
			if (typeof (element) != 'undefined' && element !== null) {
				if (window.navigator.msPointerEnabled) {
					$('#navigation-container').on('MSPointerDown', 'a', function (event) {
						app.keepActiveState($(this));
					});
				} else {
					$('#navigation-container').on('touchstart', 'a', function (event) {
						app.keepActiveState($(this).closest('li'));
					});
				}
			}

			bootstrap();

		}, false);
	} else {
		bootstrap();
	}

	app.keepActiveState = function _keepActiveState(item) {
		var currentItem = item;
		$('#navigation-container li.active').removeClass('active');
		currentItem.addClass('active');
	};

	window.app = app;

	app.isOnline = function () {
		if (!navigator || !navigator.connection) {
			return true;
		} else {
			return navigator.connection.type !== 'none';
		}
	};

	app.openLink = function (url) {
		if (url.substring(0, 4) === 'geo:' && device.platform === 'iOS') {
			url = 'http://maps.apple.com/?ll=' + url.substring(4, url.length);
		}

		window.open(url, '_system');
		if (window.event) {
			window.event.preventDefault && window.event.preventDefault();
			window.event.returnValue = false;
		}
	};

	app.showFileUploadName = function (itemViewName) {
		$('.' + itemViewName).off('change', 'input[type=\'file\']').on('change', 'input[type=\'file\']', function (event) {
			var target = $(event.target),
                inputValue = target.val(),
                fileName = inputValue.substring(inputValue.lastIndexOf('\\') + 1, inputValue.length);

			$('#' + target.attr('id') + 'Name').text(fileName);
		});

	};

	app.clearFormDomData = function (formType) {
		$.each($('.' + formType).find('input:not([data-bind]), textarea:not([data-bind])'), function (key, value) {
			var domEl = $(value),
                inputType = domEl.attr('type');

			if (domEl.val().length) {

				if (inputType === 'file') {
					$('#' + domEl.attr('id') + 'Name').text('');
				}

				domEl.val('');
			}
		});
	};

	app.checkSimulator = function () {
		if (window.navigator.simulator === true) {
			console.log('This plugin is not available in the simulator.');
			return true;
		} else if (window.plugins.toast === undefined) {
			console.log('Plugin not found. Maybe you are running in AppBuilder Companion app which currently does not support this plugin.');
			return true;
		} else {
			return false;
		}
	};

	app.getRootElementFontSize = function () {
		// Returns a number
		return parseFloat(
			// of the computed font-size, so in px
			getComputedStyle(
				// for the root <html> element
				document.documentElement
			)
			.fontSize
		);
	};

}(window));

// END_CUSTOM_CODE_kendoUiMobileApp