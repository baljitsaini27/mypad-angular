'use strict';

app.weighIn = kendo.observable({
	onShow: function () { },
	afterShow: function () { }
});

// START_CUSTOM_CODE_weighIn
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {

	parent.set('afterShow', function (e) {

		app.hideFooterButtons();

		updateUI();

		app.mobileApp.hideLoading();

	});

	function updateUI() {

		$('#li_workout').removeClass('active');
		$('#li_eat').removeClass('active');
		$('#li_activityFeed').removeClass('active');
		$('#li_weighIn').addClass('active');

		$('#txt_weight').val('');
		$('#txt_weight').focus();

	}

	parent.set('submit', function (e) {

		app.mobileApp.showLoading();

		var objectToPost = {
			JISVJIALRAVL: true,
			UserName: app.userSettings.UserName,
			WeighIn: null,
			Weight: this.weight
		};

		app.ajaxPost('http://api.cognitivegenerationenterprises.com/api/weighIn', objectToPost, postWeighIn_onSuccess, postWeighIn_onError);

	});

	parent.set('cancel', function (e) {
		goToActivityScreen();
	});

	function postWeighIn_onSuccess(response) {
		goToActivityScreen();
	}

	function postWeighIn_onError(response) { }

	function goToActivityScreen() {
		app.mobileApp.navigate("modules/activity/activityIndex.html");
	}

})(app.weighIn);

// END_CUSTOM_CODE_weighInModel