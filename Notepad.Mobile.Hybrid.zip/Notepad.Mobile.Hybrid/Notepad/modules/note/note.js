'use strict';

app.note = kendo.observable({
	onShow: function () { },
	afterShow: function () { }
});


// START_CUSTOM_CODE_weighIn
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {

	parent.set('afterShow', function (e) {

		app.hideFooterButtons();

		app.mobileApp.hideLoading();

	});

	parent.set('addNote', function (e) {

		var objectToPost = {
				JISVJIALRAVL: true,
				Contents: this.contents,
				Subject: this.subject,
				UserName: app.userSettings.UserName,
			};

		app.ajaxPost('http://api.cognitivegenerationenterprises.com/api/note', objectToPost, postNote_onSuccess, postNote_onEror);

	});

	function postNote_onSuccess(response) {
		app.mobileApp.navigate("modules/activity/activityIndex.html");
	}

	function postNote_onEror(response) {
		console.log('Error saving note: ' + response);
	}

	parent.set('cancel', function (e) {
		app.mobileApp.navigate("modules/activity/activityIndex.html");
	});

})(app.note);

// END_CUSTOM_CODE_weighIn