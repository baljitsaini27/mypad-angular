/*
This file is being used becuase I am not able to add a txt file to the project in Visual Studio.  The option is not available.  But I still would like to take notes.  I am also unaware of the impacts of adding other file types manually and knowing that this project will be compiled somehow on iOS, Android, and Windows Phone devices, so I am avoiding this risk and using this .js file.
8.12.16 - 13:30
I am going to implement  the solution for task Product Backlog Item 42:Wire up "Workout" section (Stretch, etc...).

I just noticed that I can implement dynamic titles (which I was unaware of at the time of development of the workout module) and as such I am not going to refactor workout.js now.  I will create another .js (still unsure here) or I may extend the workout.js file and just build a activityIndex.html within the workout folder.  This is a break from the normal design pattern but above are the reasons.
*/