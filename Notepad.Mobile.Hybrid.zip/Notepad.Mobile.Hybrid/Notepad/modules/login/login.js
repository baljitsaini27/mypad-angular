'use strict';

app.login = kendo.observable({
	onShow: function () { },
	afterShow: function () { }
});


// START_CUSTOM_CODE_weighIn
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {

	parent.set('afterShow', function (e) {

		// TODO: uncomment before doing build
		/*
		if (device.platform.toLowerCase() === 'android') {
			app.userSettings.UserName = 'DocGreenRob';
			$('.userName').val('DocGreenRob');
		} else {
			if (device.platform.toLowerCase() === 'ios') {
				app.userSettings.UserName = 'SadeMorgan';
				$('.userName').val('SadeMorgan');
			}
		}
		*/

		app.hideFooterButtons();

		app.hideMenu();
	});

	parent.set('login', function (e) {
		app.showMenu();
		//if (this.username == '')
			app.userSettings.UserName = 'DocGreenRob';

		//var uname = $.trim($('.userName').val().toLowerCase());
		//app.userSettings.UserName = uname;

		var activity = Singleton.getInstance('Activity');
		activity.getFeed();

		app.mobileApp.navigate('modules/activity/activityIndex.html');
	});

})(app.login);

// END_CUSTOM_CODE_weighIn