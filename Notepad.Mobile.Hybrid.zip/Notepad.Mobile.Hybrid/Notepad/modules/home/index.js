'use strict';

app.home = kendo.observable({
	onShow: function () { },
	afterShow: function () {
		window.location.href = '#index';
	}
});

// START_CUSTOM_CODE_home
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes
// check for active items

(function (parent) {

	parent.set('afterShow', function (e) {

		// set the sound for the reminder. Set here becuase tried in app.js after 'deviceready' didn't seem to work...
		// TODO: uncomment before doing build
		//app.userSettings.Sounds.railroad = device.platform == 'Android' ? 'file://railroad_crossing_bell.mp3' : 'file://beep.caf';

		// rotate and lock orientation to portrait
		// TODO: investigate.  do i really want to enforce this?
		// window.screen.lockOrientation('portrait');

		app.mobileApp.navigate("modules/login/loginIndex.html");
	});

	parent.set('clear', function (e) {
		app.toast('canceling...', function () {
			app.clearAllNotifications();
		});
	});

})(app.home);

// END_CUSTOM_CODE_home