'use strict';

app.eat = kendo.observable({
	onShow: function () { },
	afterShow: function () { },
	eatObj: {
		selectedMealItemId: 0,
		selectedMealItem: '',
		mealItems: [],
		shown: false,
		totalWeight: 0,
		eating: false,
		addingNewItem: false
	}
});

// START_CUSTOM_CODE_weighIn
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {

	parent.set('onShow', function (e) {

		if (app.eat.eatObj.shown == true)
			return;

		app.eat.eatObj.shown = true;

		var initData = null;
		var listLoaded = true;
		var dataProvider = app.data.meals,
            fetchFilteredData = function (paramFilter, searchFilter) {
            	var model = parent.get('eatModel'),
                    dataSource = model.get('dataSource');

            	if (paramFilter) {
            		model.set('paramFilter', paramFilter);
            	} else {
            		model.set('paramFilter', undefined);
            	}

            	if (paramFilter && searchFilter) {
            		dataSource.filter({
            			logic: 'and',
            			filters: [paramFilter, searchFilter]
            		});
            	} else if (paramFilter || searchFilter) {
            		dataSource.filter(paramFilter || searchFilter);
            	} else {
            		dataSource.filter({});
            	}

            	initData = dataSource._pristineData;
            },
            dataSourceOptions = {
            	type: 'json',
            	transport: {
            		read: {
            			url: dataProvider.url
            		}
            	},
            	sort: {
            		field: 'ProductName',
            		dir: 'desc'
            	},
            	serverPaging: false,
            	serverFiltering: false,
            	serverSorting: false,
            	pageSize: 50
            },
            dataSource = new kendo.data.DataSource(dataSourceOptions),
            eatModel = kendo.observable({
            	dataSource: dataSource
            });

		parent.set('eatModel', eatModel);

		$(".listview_ul").kendoMobileListView({
			dataSource: dataSource,
			template: $('.eatModelTemplate').text(),
			filterable: {
				field: 'MealItemName',
				operator: 'contains'
			},
			endlessScroll: true
		});

		var param = e.view.params.filter ? JSON.parse(e.view.params.filter) : null,
            isListmenu = false,
            backbutton = e.view.element && e.view.element.find('header [data-role="navbar"] .backButtonWrapper');

		if (param || isListmenu) {
			backbutton.show();
			backbutton.css('visibility', 'visible');
		} else {
			if (e.view.element.find('header [data-role="navbar"] [data-role="button"]').length) {
				backbutton.hide();
			} else {
				backbutton.css('visibility', 'hidden');
			}
		}

		fetchFilteredData(param);

	});

	parent.set('afterShow', function (e) {

		app.hideFooterButtons();

		updateUI();

		app.mobileApp.hideLoading();

	});

	function updateUI() {

		// TODO: Move to app.js: app.syncNavigationMenu(eat);
		$('#li_weighIn').removeClass('active');
		$('#li_workout').removeClass('active');
		$('#li_activityFeed').removeClass('active');
		$('#li_eat').addClass('active');

		if (app.eat.eatObj.eating == true && !app.eat.eatObj.addingNewItem) {
			app.eat.getCurrentMeal(null);
			window.location.href = '#eat';
		}

		$('.km-filter-wrap').find('input').focus();
	}

	parent.set('addMealItem', function (id, name) {
		app.eat.eatObj.selectedMealItemId = id;
		app.eat.eatObj.selectedMealItem = name;

		window.location.href = '#weightView';
	});

	parent.set('submit', function (e) {

		app.mobileApp.showLoading();

		var mealObj = {
			JISVJIALRAVL: true,
			MealName: app.eat.eatObj.selectedMealItemId,
			StartTime: null,
			EndTime: null,
			Weight: this.weight,
			MealItem: {
				MealItemId: app.eat.eatObj.selectedMealItemId,
				MealItemName: app.eat.eatObj.selectedMealItem
			},
			UserName: app.userSettings.UserName
		};

		app.ajaxPost('http://api.cognitivegenerationenterprises.com/api/meal/mealEntry', mealObj, postMeal_onSuccess, postMeal_onError);

	});

	function postMeal_onSuccess(response) {
		app.eat.getCurrentMeal();
	}

	function postMeal_onError(response) {
		console.log('Error posting meal: ' + response);
	}

	parent.set('getCurrentMeal', function (response) {
		app.eat.eatObj.addingNewItem = false;
		app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/meal/getCurrentItems/' + app.userSettings.UserName, getCurrentItems_onSuccess, getCurrentItems_onError);
	});

	function getCurrentItems_onSuccess(response) {

		$('#div_selectedMealItem').html('');

		app.eat.eatObj.totalWeight = 0;

		for (var i = 0; i < response.length; i++) {
			$('#div_selectedMealItem').append('<h2>' + response[i].MealName + ' ' + response[i].Weight + ' oz.</h2>');

			if (response[i].MealName.indexOf('Juice') == -1) { // if not Juice
				app.eat.eatObj.totalWeight += response[i].Weight;
			}
		}

		window.location.href = '#eat';
		$('.km-filter-reset').click();
		app.mobileApp.hideLoading();

		app.clearAllNotifications();

		var min = 60 * 1000;
		var delay = app.eat.eatObj.totalWeight * min;

		var totalWeight = app.eat.eatObj.totalWeight.toString();
		var idx = totalWeight.indexOf('.');
		var badge = idx == -1 ? totalWeight : totalWeight.substring(0, idx);

		if (!app.checkSimulator()) {
			cordova.plugins.notification.local.schedule({
				id: 1,
				title: 'Still eating?',
				text: badge + ' mins since you started...',
				sound: app.userSettings.Sounds.railroad,
				badge: badge,
				every: 1,
				led: 'FFFF00',
				autoClear: true,
				firstAt: new Date(new Date().getTime() + delay)
			});
		}

	}

	function getCurrentItems_onError(response){
		console.log('Error getting current items: ' + response);
	}

	parent.set('end', function (e) {
		app.mobileApp.showLoading();
		app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/meal/end/' + app.userSettings.UserName, getMealEnd_onSuccess, getMealEnd_onError);
	});

	function getMealEnd_onSuccess(response){

		app.clearAllNotifications();

		// set another notification for the next meal
		// just set for 3 hours later if less than midnight and greater than 7 am
		var d = new Date();
		var hours = d.getHours();

		app.toast('End...', function () {
			if (hours > 7) {
				cordova.plugins.notification.local.schedule({
					id: 1,
					title: '3 Hours Since Last Meal...',
					text: '... let\'s eat!',
					sound: app.userSettings.Sounds.railroad,
					badge: 3,
					every: 15,
					led: 'FF0000',
					autoClear: true,
					at: new Date(new Date().getTime() + (3 * 60 * 60 * 1000))
				});

				app.toast('Set 3 hour reminder', function () {

					setTimeout(function () {
						app.mobileApp.navigate("modules/activity/activityIndex.html");
					}, 3000);
				});
			}
		});

	}

	function getMealEnd_onError(response){
		console.log('Error ending meal: ' + error);
	}

	parent.set('add', function (e) {
		app.eat.eatObj.addingNewItem = true;
		window.location.href = '#itemSelector';
	});

	parent.set('onShowWeightEntry', function (e) {

	});

	parent.set('afterShowWeightEntry', function (e) {
		$('.weight').val('');
		$('.weight').focus();
	});

})(app.eat);

// END_CUSTOM_CODE_weighIn