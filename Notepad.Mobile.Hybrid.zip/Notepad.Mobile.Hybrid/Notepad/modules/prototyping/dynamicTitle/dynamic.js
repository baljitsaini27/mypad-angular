'use strict';
app.title = kendo.observable({
	onShow: function () { },
	afterShow: function () { }
});

// START_CUSTOM_CODE_weighIn
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {
	parent.set('updateTitle', function (e) {
		var title = new Date().getMilliseconds();
		$("#navbar").data("kendoMobileNavBar").title("Title " + title);
	});
})(app.title);

// END_CUSTOM_CODE_weighIn