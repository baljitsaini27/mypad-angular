    'use strict';
app.acHome = kendo.observable({
	onShow: function () { },
	afterShow: function () {
		var title = app.acHome.workoutActivityObj.title;
		$("#navbar").data("kendoMobileNavBar").title(title);
	},
	workoutActivityObj: {
		title: ''
	},
	updateTitle: function () { }
});

// START_CUSTOM_CODE_weighIn
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {
	parent.set('updateTitle', function (e) {
		var title = app.acHome.workoutActivityObj.title;
		//alert('2. do this: ' + title);
		//$("#navbar").data("kendoMobileNavBar").workoutActivity(title);
	});

	parent.set('updateTitle2', function (e) {
		var title = app.acHome.workoutActivityObj.title;
		$("#navbar").data("kendoMobileNavBar").title(title);
	});
})(app.acHome);

// END_CUSTOM_CODE_weighIn