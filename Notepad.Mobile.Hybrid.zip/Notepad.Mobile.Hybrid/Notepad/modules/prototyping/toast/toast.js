'use strict';

app.toast = kendo.observable({
	onShow: function () {

	},
	afterShow: function () {
	}
});

// START_CUSTOM_CODE_weighIn
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {
	var DemoViewModel

	DemoViewModel = kendo.data.ObservableObject.extend({

		// short lasting messages
		showToast_shortTop: function () {
			if (!this.checkSimulator()) {
				window.plugins.toast.showShortTop('This talk is boring', this.onSuccess, this.onError);
			}
		},

		showToast_shortCenter: function () {
			if (!this.checkSimulator()) {
				window.plugins.toast.showShortCenter('Yeah is there another room?', this.onSuccess, this.onError);
			}
		},

		showToast_shortBottom: function () {
			if (!this.checkSimulator()) {
				window.plugins.toast.showShortBottom('I\'m staying, this guy is awesome!', this.onSuccess, this.onError);
			}
		},

		// longer lasting messages
		showToast_longTop: function () {
			if (!this.checkSimulator()) {
				window.plugins.toast.showLongTop('Booooooooooring! Boring boring boring', this.onSuccess, this.onError);
			}
		},

		showToast_longCenter: function () {
			if (!this.checkSimulator()) {
				window.plugins.toast.showLongCenter('Yeah - let\'s grab some coffee', this.onSuccess, this.onError);
			}
		},

		showToast_longBottom: function () {
			if (!this.checkSimulator()) {
				window.plugins.toast.showLongBottom('I apologize for my fellow Toasts', this.onSuccess, this.onError);
			}
		},

		showToast_smallGreen: function () {
			if (!this.checkSimulator()) {
				window.plugins.toast.showWithOptions(
                  {
                  	message: 'Small green opaque',
                  	duration: 'long',
                  	position: 'bottom',
                  	styling: {
                  		backgroundColor: '#4B946A', // green
                  		textColor: '#DDDDDD', // lightgray
                  		cornerRadius: 10,
                  		opacity: 1.0,
                  		horizontalPadding: 12,
                  		verticalPadding: 6
                  	}
                  },
                  this.onSuccess,
                  this.onError
            )
			}
		},

		showToast_largeRed: function () {
			if (!this.checkSimulator()) {
				window.plugins.toast.showWithOptions(
                  {
                  	message: 'Red with lots of padding',
                  	duration: 'long',
                  	position: 'bottom',
                  	styling: {
                  		backgroundColor: '#FF0000', // red
                  		textColor: '#FFFF00', // yellow
                  		cornerRadius: 6,
                  		opacity: 0.75,
                  		horizontalPadding: 40,
                  		verticalPadding: 40
                  	}
                  },
                  this.onSuccess,
                  this.onError
            )
			}
		},

		showToast_longBottomMin40px: function () {
			if (!this.checkSimulator()) {
				window.plugins.toast.showWithOptions(
                  {
                  	message: "I'm positioned a bit higher",
                  	duration: "long",
                  	position: "bottom",
                  	addPixelsY: -40
                  },
                  this.onSuccess,
                  this.onError
            )
			}
		},

		showToast_longBottomPlus30px: function () {
			if (!this.checkSimulator()) {
				window.plugins.toast.showWithOptions(
                  {
                  	message: "I'm positioned a bit lower",
                  	duration: "long",
                  	position: "bottom",
                  	addPixelsY: 30
                  },
                  this.onSuccess,
                  this.onError
            )
			}
		},

		hideToast: function () {
			if (!this.checkSimulator()) {
				window.plugins.toast.hide(this.onSuccess, this.onError);
			}
		},

		checkSimulator: function () {
			alert('1');

			alert(window.plugins);
			if (window.navigator.simulator === true) {
				alert('2');
				alert('This plugin is not available in the simulator.');
				return true;
			} else if (window.plugins.toast === undefined) {
				alert('3');
				alert('Plugin not found. Maybe you are running in AppBuilder Companion app which currently does not support this plugin.');
				return true;
			} else {
				alert('4');
				alert('returning false');
				return false;
			}
			alert('5');
		},

		// callbacks
		onSuccess: function (msg) {
			console.log('Toast shown: ' + msg);
		},

		onError: function (msg) {
			alert('Toast error: ' + msg);
		}
	});

	app.toast = {
		viewModel: new DemoViewModel()
	};
})(app.toast);

// END_CUSTOM_CODE_weighIn