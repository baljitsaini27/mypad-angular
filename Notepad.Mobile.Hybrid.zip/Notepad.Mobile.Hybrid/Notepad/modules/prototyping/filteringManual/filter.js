'use strict';

app.filter = kendo.observable({
	onShow: function () {},
	afterShow: function () {},
	filterObj: {
		selectedMealItemId: 0,
		selectedMealItem: '',
		mealItems: [],
		shown: false
	}
});

// START_CUSTOM_CODE_weighIn
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {
	parent.set('afterShow', function(e){
		$('.km-filter-wrap').find('input').focus();
	});
	
	parent.set('addMealItem', function (id, name) {
		app.filter.filterObj.selectedMealItemId = id;
		app.filter.filterObj.selectedMealItem = name;

		window.location.href = '#weightView';
	});

	parent.set('submit', function (e) {
		app.mobileApp.showLoading();
		var mealObj = {
			JISVJIALRAVL: true,
			MealName: app.filter.filterObj.selectedMealItemId1,
			StartTime: null,
			EndTime: null,
			Weight: this.weight,
			MealItem: {
				MealItemId: app.filter.filterObj.selectedMealItemId,
				MealItemName: app.filter.filterObj.selectedMealItem
			},
			UserName: app.userSettings.UserName
		};

		var json = JSON.stringify(mealObj);

		$.ajax({
			url: 'http://api.cognitivegenerationenterprises.com/api/meal/mealEntry',
			type: 'POST',
			contentType: 'application/json; charset=utf-8',
			data: json,
			dataType: 'json',
			success: function (response) {
				// request succeeded
				console.log('record saved');
				$.ajax({
					url: 'http://api.cognitivegenerationenterprises.com/api/meal/getCurrentItems/' + app.userSettings.UserName,
					type: 'GET',
					contentType: 'application/json; charset=utf-8',
					success: function (response) {
						// request succeeded
						$('#div_selectedMealItem').html('');
						for (var i = 0; i < response.length; i++) {
							$('#div_selectedMealItem').append('<h2>' + response[i].MealName + ' ' + response[i].Weight + '</h2>');
						}
						
						window.location.href = '#eat';
						$('.km-filter-reset').click();
						app.mobileApp.hideLoading();
					},
					error: function (error) {
						// request failed
						console.log('Get Open activity error: ' + error);
					}
				});
			},
			error: function (error) {
				// request failed
				console.log('error: ' + error);
			}
		});
	});

	parent.set('end', function (e) {
		app.mobileApp.showLoading();

		$.ajax({
			url: 'http://api.cognitivegenerationenterprises.com/api/meal/end/' + app.userSettings.UserName,
			type: 'GET',
			contentType: 'application/json; charset=utf-8',
			success: function (response) {
				// request succeeded
				app.mobileApp.navigate("modules/activity/activityIndex.html");
			},
			error: function (error) {
				// request failed
				console.log('error: ' + error);
			}
		});
	});
	
	parent.set('add', function (e) {
		window.location.href = '#itemSelector';
	});

	parent.set('onShow', function (e) {

		if (app.filter.filterObj.shown == true)
			return;

		app.filter.filterObj.shown = true;

		var initData = null;
		var listLoaded = true;
		var dataProvider = app.data.meals,

			fetchFilteredData = function (paramFilter, searchFilter) {
				var model = parent.get('filterModel'),
					dataSource = model.get('dataSource');

				if (paramFilter) {
					model.set('paramFilter', paramFilter);
				} else {
					model.set('paramFilter', undefined);
				}

				if (paramFilter && searchFilter) {
					dataSource.filter({
						logic: 'and',
						filters: [paramFilter, searchFilter]
					});
				} else if (paramFilter || searchFilter) {
					dataSource.filter(paramFilter || searchFilter);
				} else {
					dataSource.filter({});
				}

				initData = dataSource._pristineData;
			},
			dataSourceOptions = {
				type: 'json',
				transport: {
					read: {
						url: dataProvider.url
					}
				},
				sort: {
					field: "ProductName",
					dir: "desc"
				},
				serverPaging: false,
				serverFiltering: false,
				serverSorting: false,
				pageSize: 50
			},
			dataSource = new kendo.data.DataSource(dataSourceOptions),
			filterModel = kendo.observable({
				dataSource: dataSource
			});

		parent.set('filterModel', filterModel);

		$("#listview").kendoMobileListView({
			dataSource: dataSource,
			template: $("#activityModelTemplate").text(),
			filterable: {
				field: "MealItemName",
				operator: "contains"
			},
			endlessScroll: true
		});

		$('#li_weighIn').removeClass('active');
		$('#li_workout').removeClass('active');
		$('#li_activityFeed').addClass('active');

		var param = e.view.params.filter ? JSON.parse(e.view.params.filter) : null,
			isListmenu = false,
			backbutton = e.view.element && e.view.element.find('header [data-role="navbar"] .backButtonWrapper');

		if (param || isListmenu) {
			backbutton.show();
			backbutton.css('visibility', 'visible');
		} else {
			if (e.view.element.find('header [data-role="navbar"] [data-role="button"]').length) {
				backbutton.hide();
			} else {
				backbutton.css('visibility', 'hidden');
			}
		}

		fetchFilteredData(param);
	});

	parent.set('onShowWeightEntry', function (e) {

	});

	parent.set('onAfterShowWeightEntry', function (e) {
		$('#weight').val('');
		$('#weight').focus();
	});

})(app.filter);

// END_CUSTOM_CODE_weighIn