'use strict';

app.timer = kendo.observable({
	onShow: function () { },
	afterShow: function () { },
	timerObj: {
		duration: '',
		complete: false
	}
});

// START_CUSTOM_CODE_weighIn
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {
	var hours;
	var minutes;
	var seconds;
	var finalDisplay;
	var incrementer;
	var timer;

	function updateDisplay() {
		if (timer < 10) {
			seconds = '0' + timer;
		} else {
			if (timer < 60) {
				seconds = timer;
			} else {
				// timer is 60, minute change
				timer = 0; // test with 0
				seconds = '00';
				console.log('increment minutes');
				// increment minutes
				var _minutes = Number(minutes);
				if (_minutes < 60) {
					_minutes++;
					if (_minutes < 10) {
						minutes = '0' + _minutes;
					} else {
						minutes = _minutes;
					}
					console.log('Minutes: ' + minutes);
				} else {
					console.log('increment hours');
					// increment hours
					minutes = '00';
					var _hours = Number(hours);
					_hours++;
					if (_hours < 10) {
						hours = '0' + _hours;
					} else {
						hours = _hours;
					}
				}
			}
		}
		minutes = (minutes == undefined) ? '00' : minutes;
		hours = (hours == undefined || isNaN(hours)) ? '00' : hours;
		console.log('hours: ' + hours);
		finalDisplay = hours + ':' + minutes + ':' + seconds;
		console.log(finalDisplay);
	}

	function tick() {
		throw new Error('Should not be ...');
		timer++;
		updateDisplay();
		increment();
		$("#div_timer").html(finalDisplay); //display the result
		kendo.bind($("#div_timer"), app.workout, kendo.mobile.ui);


	}

	function increment() {
		incrementer = setTimeout(tick, 1000);
	};

	parent.set('afterShow', function (e) {
		$("#div_timer").html("00:00:00"); //display the result
		kendo.bind($("#div_timer"), app.workout, kendo.mobile.ui);
		// div_display
		$("#div_display").html(app.workout.workoutObj.Display); //display the result
		kendo.bind($("#div_display"), app.workout, kendo.mobile.ui);
	});

	parent.set('startTimer', function (e) {
		tick();
		$(".startTimer").css("display", "none");
		$(".endTimer").css("display", "block");

		// if timer is for workout
		if (app.workout.workoutObj.ActivityType == "workout") {
			var objectToPost = {
				BodyPart: app.workout.workoutObj.SelectedBodyPart,
				Distance: null,
				Duration: null,
				EndTimeString: null,
				ExerciseName: null,
				Reps: null,
				StartTimeString: null,
				Type: "workout",
				UserName: app.userSettings.UserName,
				Weight: null,
				WorkoutName: app.workout.workoutObj.SelectedAction
			};

			var json = JSON.stringify(objectToPost);

			$.ajax({
				url: 'http://api.cognitivegenerationenterprises.com/api/physicalEntry',
				type: 'POST',
				contentType: 'application/json; charset=utf-8',
				data: json,
				dataType: 'json',
				success: function (response) {
					// request succeeded
					app.workout.workoutObj.PhysicalEntryId = response;
					console.log('workout started: ' + response);
				},
				error: function (error) {
					// request failed
					console.log('error: ' + error);
				}
			});
		}

		if (app.workout.workoutObj.ActivityType == "exercise") {
			var objectToPost = {
				BodyPart: app.workout.workoutObj.SelectedBodyPart,
				Distance: null,
				Duration: null,
				EndTimeString: null,
				ExerciseName: app.workout.workoutObj.SelectedAction,
				Reps: null,
				StartTimeString: null,
				Type: "exercise",
				UserName: app.userSettings.UserName,
				Weight: null,
				WorkoutName: app.workout.workoutObj.SelectedAction
			};

			var json = JSON.stringify(objectToPost);

			$.ajax({
				url: 'http://api.cognitivegenerationenterprises.com/api/physicalEntry',
				type: 'POST',
				contentType: 'application/json; charset=utf-8',
				data: json,
				dataType: 'json',
				success: function (response) {
					// request succeeded
					app.workout.workoutObj.PhysicalEntryId = response;
					console.log('workout started: ' + response);
				},
				error: function (error) {
					// request failed
					console.log('error: ' + error);
				}
			});
		}

	});

	parent.set('endTimer', function (e) {
		$(".endTimer").css("display", "none");
		clearTimeout(incrementer);
		app.timer.timerObj.duration = finalDisplay;
		app.timer.timerObj.complete = true;

		if (app.workout.workoutObj.ActivityType == "workout") {
			app.mobileApp.navigate("modules/workout/workoutIndex.html");
		}

		if (app.workout.workoutObj.ActivityType == "exercise") {
			app.mobileApp.navigate("modules/workout/workoutIndex.html");
		}
	});
})(app.timer);

// END_CUSTOM_CODE_weighIn