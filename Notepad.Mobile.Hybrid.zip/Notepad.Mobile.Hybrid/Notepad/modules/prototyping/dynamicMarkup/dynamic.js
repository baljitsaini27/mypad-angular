'use strict';

app.dynamic = kendo.observable({
	onShow: function () {

	},
	afterShow: function () {

	},
	startWorkout: function (e) {
		var data = e.button.data();
		console.log('Clicked: ' + data.id);
	},
	onClickStaticButton: function () {
		console.log("event :: click");
		this.generateDynamicButtons();
	},

	generateDynamicButtons: function () {
		var list = [
			{
				Name: 'Item 1',
				Id: 1
			},
			{
				Name: 'Item 2',
				Id: 2
			},
			{
				Name: 'Item 3',
				Id: 3
			}
		];

		var string = '';

		for (var i = 0; i < list.length; i++) {
			string += '<button data-role="button" class="button" data-bind="events: {click: onClickDynamicButton}" data-bodypart="' + list[i].Id + '">' + list[i].Name + '</button><br/><br/>';
		}

		$('#div_output').html(string);
		kendo.bind($("#div_output"), app.dynamic, kendo.mobile.ui);
	},

	onClickDynamicButton: function () {
		console.log('app.timer.objProps.duration: ' + app.timer.objProps.duration);
		console.log("dynamic button click");
	}
});

// START_CUSTOM_CODE_weighIn
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes


// END_CUSTOM_CODE_weighIn