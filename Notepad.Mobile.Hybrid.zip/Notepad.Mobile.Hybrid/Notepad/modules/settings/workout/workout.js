'use strict';

app.workoutSettings = kendo.observable({
	onShow: function () { },
	afterShow: function () { },
	workoutSettingsObj: {}
});

// START_CUSTOM_CODE_settings
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {

	parent.set('onShow', function (e) { });

	parent.set('afterShow', function (e) { });

	parent.set('manageTypes', function (e) {
		app.mobileApp.navigate("modules/settings/workout/workoutType/workoutTypeIndex.html");
	});

	parent.set('setTypesRequirements', function (e) {
		app.mobileApp.navigate("modules/settings/workout/workoutTypeRuleInterstatial/workoutTypeRuleInterstatialIndex.html");
	});

})(app.workoutSettings);

// END_CUSTOM_CODE_settings