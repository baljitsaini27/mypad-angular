'use strict';

app.workoutTypeRule = kendo.observable({
	onShow: function () { },
	afterShow: function () { },
	workoutTypeRuleObj: {
		e: {},
		edit: false,
		selectedBodyParts: [],
		changing_min_bodyPartImpact: false,
		changing_timePerWI: false,
		editOrView: false,
		id: 0
	}
});

// START_CUSTOM_CODE_settings
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {

	parent.set('onShow', function (e) { });

	parent.set('afterShow', function (e) {

		app.hideFooterButtons();

		resetView();

		setEventListeners(e);

		populateView();

		updateUI();

		app.mobileApp.hideLoading();

	});

	function resetView() {

		// get workout types for <select>
		app.ajaxGet(app.workoutType.workoutTypeObj.data.url, getWorkoutTypes_onSuccess, getWorkoutTypes_onError);

		// set multiple body part switch
		$.fn.bootstrapSwitch.defaults.onText = 'YES';
		$.fn.bootstrapSwitch.defaults.offText = 'NO';

		$("[name='multipleBodyParts']").bootstrapSwitch();
		$("[name='seeDetails']").bootstrapSwitch();

		// set multiple body parts switch
		var state = $('#multipleBodyParts').bootstrapSwitch('state');
		if (state == false) {
			$('#multipleBodyParts').bootstrapSwitch('toggleState');
		}

		// uncheck all body parts
		uncheckAllBodyParts();

		// clear minimum sets
		$('#min_sets').val('');

		// clear minimum reps
		$('#min_reps').val('');

		// clear minimum weight
		$('#min_weight').val('');

		// clear minimum body part impact
		$('#min_bodyPartImpact').val('');

		// clear minimum duration
		$('#min_duration').val('');

		// set see details switch
		state = $('#seeDetails').bootstrapSwitch('state');
		if (state == false) {
			$('#seeDetails').bootstrapSwitch('toggleState');
		}

		// clear times per wi
		$('#timePerWI').val('');

		// clear start date
		$('#startDate').val('');

		// clear end date
		$('#endDate').val('');

		// re-enable all input elements
		$('#open_min_sets').trigger('click');
		$('#open_min_reps').trigger('click');
		$('#open_min_weight').trigger('click');
		$('#open_min_duration').trigger('click');
		$('#open_seeDetails').trigger('click');
		$('#open_startDate').trigger('click');
		$('#open_endDate').trigger('click');

	}

	function setEventListeners(e) {

		$('#bodyPartImg_abs').click(function () {

			var imgName = $(this).find('img').attr('src');
			var newImg = '';

			if (imgName.indexOf('-check') != -1) {
				newImg = '<img src="images/abs.png" class="bodyPartImg" />';
				unselectBodyPart('abs');
			} else {
				newImg = '<img src="images/abs-check.png" class="bodyPartImg" />';
				app.workoutTypeRule.workoutTypeRuleObj.selectedBodyParts.push('abs');
			}

			$(this).empty();
			$(this).html(newImg);

			showSaveButton();

		});

		$('#bodyPartImg_arms').click(function () {

			var imgName = $(this).find('img').attr('src');
			var newImg = '';

			if (imgName.indexOf('-check') != -1) {
				newImg = '<img src="images/arm.png" class="bodyPartImg" />';
				unselectBodyPart('arms');
			} else {
				newImg = '<img src="images/arm-check.png" class="bodyPartImg" />';
				app.workoutTypeRule.workoutTypeRuleObj.selectedBodyParts.push('arms');
			}

			$(this).empty();
			$(this).html(newImg);

			showSaveButton();

		});

		// back
		$('#bodyPartImg_back').click(function () {

			var imgName = $(this).find('img').attr('src');
			var newImg = '';

			if (imgName.indexOf('-check') != -1) {
				newImg = '<img src="images/back.png" class="bodyPartImg" />';
				unselectBodyPart('back');
			} else {
				newImg = '<img src="images/back-check.png" class="bodyPartImg" />';
				app.workoutTypeRule.workoutTypeRuleObj.selectedBodyParts.push('back');
			}

			$(this).empty();
			$(this).html(newImg);

			showSaveButton();

		});

		// chest
		$('#bodyPartImg_chest').click(function () {

			var imgName = $(this).find('img').attr('src');
			var newImg = '';

			if (imgName.indexOf('-check') != -1) {
				newImg = '<img src="images/chest.png" class="bodyPartImg" />';
				unselectBodyPart('chest');
			} else {
				newImg = '<img src="images/chest-check.png" class="bodyPartImg" />';
				app.workoutTypeRule.workoutTypeRuleObj.selectedBodyParts.push('chest');
			}

			$(this).empty();
			$(this).html(newImg);

			showSaveButton();

		});

		// legs
		$('#bodyPartImg_legs').click(function () {

			var imgName = $(this).find('img').attr('src');
			var newImg = '';

			if (imgName.indexOf('-check') != -1) {
				newImg = '<img src="images/leg.png" class="bodyPartImg" />';
				unselectBodyPart('legs');
			} else {
				newImg = '<img src="images/leg-check.png" class="bodyPartImg" />';
				app.workoutTypeRule.workoutTypeRuleObj.selectedBodyParts.push('legs');
			}

			$(this).empty();
			$(this).html(newImg);

			showSaveButton();

		});

		// shoulder
		$('#bodyPartImg_shoulders').click(function () {

			var imgName = $(this).find('img').attr('src');
			var newImg = '';

			if (imgName.indexOf('-check') != -1) {
				newImg = '<img src="images/shoulder.png" class="bodyPartImg" />';
				unselectBodyPart('shoulders');
			} else {
				newImg = '<img src="images/shoulder-check.png" class="bodyPartImg" />';
				app.workoutTypeRule.workoutTypeRuleObj.selectedBodyParts.push('shoulders');
			}

			$(this).empty();
			$(this).html(newImg);

			showSaveButton();

		});

		bindClose();

		$('.help').click(function () {

			var title = '';
			var text = '';
			var $div = $(this).closest('.row');

			switch ($div.attr('id')) {
				case 'div_multipleBodyParts':
					title = 'Multiple Body Parts';
					text = 'Is the focus of this activity more than one body part?';
					break;
				case 'div_chooseBodyPart':
					title = 'Choose Body Parts';
					text = 'Select all the body parts this activity will impact.';
					break;
				case 'div_min_sets':
					title = 'Minimum Sets';
					text = 'Each time this activity is done, what are the <u>minimum sets</u> you require?';
					break;
				case 'div_min_reps':
					title = 'Minimum Reps';
					text = 'Each time this activity is done, what are the <u>minimum reps</u> you require?';
					break;
				case 'div_min_weight':
					title = 'Minimum Weight';
					text = 'Each time this activity is done, what are the <u>minimum weight</u> you require? (for example, I want to bench at least 200 lbs.)';
					break;
				case 'div_min_bodyPartImpact':
					title = 'Minimum Body Part Impact';
					text = 'Each time this activity is done, what are the <u>minimum number of body parts</u> that should be impacted?';
					break;
				case 'div_min_duration':
					title = 'Minimum Duration';
					text = 'Each time this activity is done, what are the <u>minimum number of minutes</u> that should be done?';
					break;
				case 'div_seeDetails':
					title = 'See Details';
					text = 'When looking that the results on the dashboard, do you want to be able to see the details (of what makes up this ...';
					break;
				case 'div_timePerWI':
					title = 'Times Per Workout Interval (WI)';
					text = 'Where <i>WI</i> = Workout Interval (the number you set for the rules earlier) (for example, the normal/default WI is 7 or each week). <br/><br/> So, how many times per WI do you want to do this activity?';
					break;
				case 'div_startDate':
					title = 'Start Date';
					text = 'What is the <u>Start Date</u> for this activity?';
					break;
				case 'div_endDate':
					title = 'End Date';
					text = 'What is the <u>End  Date</u> for this activity?';
					break;
			}

			showModal(title, text);

		});

		$('.closeHelp').click(function () {
			$("#foo").data("kendoMobileModalView").close();
		});

		$('.sel_workoutTypes').change(function () {
			showSaveButton();
		});

		$(":input").bind('keyup mouseup', function () {

			app.workoutTypeRule.workoutTypeRuleObj.changing_min_bodyPartImpact = false;
			app.workoutTypeRule.workoutTypeRuleObj.changing_timePerWI = false;

			if ($(this).attr('id') == 'min_bodyPartImpact') {
				app.workoutTypeRule.workoutTypeRuleObj.changing_min_bodyPartImpact = true;
				showSaveButton();
			}

			if ($(this).attr('id') == 'timePerWI') {
				app.workoutTypeRule.workoutTypeRuleObj.changing_timePerWI = true;
				showSaveButton();
			}

		});

		$('.saveButton').click(function () {

			var obj = {
				TypeId: $('.sel_workoutTypes option:selected').val(),
				BodyParts: app.convertArrayToString(app.workoutTypeRule.workoutTypeRuleObj.selectedBodyParts, ','),
				Min_Sets: app.notNullOrZero($('#min_sets').val()) ? $('#min_sets').val() : null,
				Min_Reps: app.notNullOrZero($('#min_reps').val()) ? $('#min_reps').val() : null,
				Min_Distance: null, // TODO: Implement!!
				Min_Duration: app.notNullOrZero($('#min_duration').val()) ? $('#min_duration').val() : null,
				Min_Weight: app.notNullOrZero($('#min_weight').val()) ? $('#min_weight').val() : null,
				Min_Body_Part_Impact: app.notNullOrZero($('#min_bodyPartImpact').val()) ? $('#min_bodyPartImpact').val() : null,
				Details: $('#seeDetails').prop('checked'),
				TimesPerWI: app.notNullOrZero($('#timePerWI').val()) ? $('#timePerWI').val() : null,
				StartDate: app.notNullOrZero($('#startDate').val()) ? $('#startDate').val() : null,
				EndDate: app.notNullOrZero($('#endDate').val()) ? $('#endDate').val() : null,
				UserName: app.userSettings.UserName
			};

			app.ajaxPost('http://api.cognitivegenerationenterprises.com/api/userSettings/WorkoutType/CreateRule', obj, postCreateWorkoutTypeRule_onSuccess, postCreateWorkoutTypeRule_onError);

		});

	}

	function populateView() {

		if ($('#multipleBodyParts').bootstrapSwitch('state') == false) {
			$('#multipleBodyParts').bootstrapSwitch('toggleState');
		}

		if (app.workoutTypeRule.workoutTypeRuleObj.editOrView == true) {

			app.mobileApp.showLoading();
			app.workoutTypeRule.workoutTypeRuleObj.editOrView = false;

			app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/userSettings/WorkoutType/GetRule/' + app.workoutTypeRule.workoutTypeRuleObj.id + '/' + app.userSettings.UserName,
				function (response) {
					setTimeout(function () {

						// set the rule ddl
						$('.sel_workoutTypes option[value="' + response.TypeId + '"]').attr('selected', 'selected');
						$('.sel_workoutTypes').change();

						// set multiple body parts switch
						var state = $('#multipleBodyParts').bootstrapSwitch('state');
						if (state == true && response.MultipleBodyParts == false) {
							$('#multipleBodyParts').bootstrapSwitch('toggleState');
						}

						// set checked body parts
						showCheckedBodyParts(response.BodyParts);

						// set minimum sets
						if (app.notNullOrZero(response.Min_Sets) == false) {
							$('#close_min_sets').trigger('click');
						} else {
							$('#min_sets').val(response.Min_Sets);
						}


						// set minimum reps
						if (app.notNullOrZero(response.Min_Reps) == false) {
							$('#close_min_reps').trigger('click');
						} else {
							$('#min_reps').val(response.Min_Reps);
						}

						// set minimum weight
						if (app.notNullOrZero(response.Min_Weight) == false) {
							$('#close_min_weight').trigger('click');
						} else {
							$('#min_weight').val(response.Min_Weight);
						}

						// set minimum body part Impact
						$('#min_bodyPartImpact').val(response.Min_Body_Part_Impact);

						// set minimum duration
						if (app.notNullOrZero(response.Min_Duration) == false) {
							$('#close_min_duration').trigger('click');
						} else {
							$('#min_duration').val(response.Min_Duration);
						}

						// set see details switch
						state = $('#seeDetails').bootstrapSwitch('state');
						if (state == true && response.Details == false) {
							$('#seeDetails').bootstrapSwitch('toggleState');
						}

						// set times per WI
						$('#timePerWI').val(response.TimesPerWI);

						// set start date
						if (app.notNullOrZero(response.StartDate) == true) {
							$('#startDate').val(response.StartDate.substring(0, response.StartDate.indexOf('T')));
						} else {
							$('#close_startDate').trigger('click');
						}

						// set end date
						if (app.notNullOrZero(response.EndDate) == true) {
							$('#endDate').val(response.EndDate.substring(0, response.EndDate.indexOf('T')));
						} else {
							$('#close_endDate').trigger('click');
						}

						setEventListeners();

						$(":input").bind('keyup mouseup', function () {
							showSaveButton();
						});

					}, 500);
				}
				, function (response) {
					console.log('Error getting workout rule from populate view: ' + response);
				});
		}

	}

	function updateUI() {
		app.showFooterButton('images/rule-6.png', returnToWorkoutRuleTypeInterstatial);
	}

	function uncheckAllBodyParts() {
		$('#bodyPartImg_abs').html('<img src="images/abs.png" class="bodyPartImg" />');
		$('#bodyPartImg_arms').html('<img src="images/arm.png" class="bodyPartImg" />');
		$('#bodyPartImg_back').html('<img src="images/back.png" class="bodyPartImg" />');
		$('#bodyPartImg_chest').html('<img src="images/chest.png" class="bodyPartImg" />');
		$('#bodyPartImg_legs').html('<img src="images/leg.png" class="bodyPartImg" />');
		$('#bodyPartImg_shoulders').html('<img src="images/shoulder.png" class="bodyPartImg" />');
	}

	function showCheckedBodyParts(bodyParts) {

		var bodyPartsArray = [];

		if (bodyParts.indexOf(',') == -1)
			bodyPartsArray.push(bodyParts)
		else
			bodyPartsArray = bodyParts.split(',');

		for (var i = 0; i < bodyPartsArray.length; i++) {

			switch (bodyPartsArray[i].toLowerCase()) {
				case 'abs':
					$('#bodyPartImg_abs').html('');
					$('#bodyPartImg_abs').html('<img src="images/abs-check.png" class="bodyPartImg" />');
					break;
				case 'arms':
					$('#bodyPartImg_arms').html('');
					$('#bodyPartImg_arms').html('<img src="images/arm-check.png" class="bodyPartImg" />');
					break;
				case 'back':
					$('#bodyPartImg_back').html('');
					$('#bodyPartImg_back').html('<img src="images/back-check.png" class="bodyPartImg" />');
					break;
				case 'chest':
					$('#bodyPartImg_chest').html('');
					$('#bodyPartImg_chest').html('<img src="images/chest-check.png" class="bodyPartImg" />');
					break;
				case 'legs':
					$('#bodyPartImg_legs').html('');
					$('#bodyPartImg_legs').html('<img src="images/leg-check.png" class="bodyPartImg" />');
					break;
				case 'shoulder':
					$('#bodyPartImg_shoulders').html('');
					$('#bodyPartImg_shoulders').html('<img src="images/shoulder-check.png" class="bodyPartImg" />');
					break;
			}

			app.workoutTypeRule.workoutTypeRuleObj.selectedBodyParts.push(bodyPartsArray[i].toLowerCase());

		}

		showSaveButton();

	}

	function getWorkoutTypes_onSuccess(response) {

		$('.sel_workoutTypes').find('option').remove().end();
		$('.sel_workoutTypes').append($('<option/>', {
			value: 0,
			text: 'Select One'
		}));

		for (var i = 0; i < response.length; i++) {
			$('.sel_workoutTypes').append($('<option/>', {
				value: response[i].WorkoutActivityTypeId,
				text: response[i].WorkoutType
			}));
		}

		// bind onChange
		$('.sel_workoutTypes').change(function () {
			var val = $(this).val();

			// get the rule (if it exists)
			app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/userSettings/WorkoutType/GetRule/' + val + '/' + app.userSettings.UserName, getWorkoutTypeRule_onSuccess, getWorkoutTypeRule_onError);
		});

	}

	function getWorkoutTypeRule_onSuccess(response) {
		if (response.WorktoutTypeRuleId == 0) {
			// show edit
			app.workoutTypeRule.workoutTypeRuleObj.edit = true;
		}
	}

	function getWorkoutTypeRule_onError(response) {
		console.log('Error getting workout type rule: ' + response);
	}

	function getWorkoutTypes_onError(response) {
		console.log('Error getting workout types: ' + response);
	}

	function postCreateWorkoutTypeRule_onSuccess(response) {
		app.mobileApp.navigate('modules/settings/workout/workoutTypeRuleInterstatial/workoutTypeRuleInterstatialIndex.html');
	}

	function postCreateWorkoutTypeRule_onError(response) {
		console.log('Error creating new workout type rule:' + error);
	}

	function bindClose() {

		$('.close').click(function () {

			var id = $(this).attr('id');

			switch (id) {
				case 'close_min_sets':

					var $div = $('#div_min_sets');
					$div.find('h2').css('color', '#ccc');

					$('#div_toggle_min_sets').empty();
					$('#div_toggle_min_sets').html('<img src="images/hyphen.png" class="open" id="open_min_sets" />');

					var $txt = $div.find('input');
					$txt.prop('disabled', true);

					break;
				case 'close_min_reps':

					var $div = $('#div_min_reps');
					$div.find('h2').css('color', '#ccc');

					$('#div_toggle_min_reps').empty();
					$('#div_toggle_min_reps').html('<img src="images/hyphen.png" class="open" id="open_min_reps" />');

					var $txt = $div.find('input');
					$txt.prop('disabled', true);

					break;
				case 'close_min_weight':

					var $div = $('#div_min_weight');
					$div.find('h2').css('color', '#ccc');

					$('#div_toggle_min_weight').empty();
					$('#div_toggle_min_weight').html('<img src="images/hyphen.png" class="open" id="open_min_weight" />');

					var $txt = $div.find('input');
					$txt.prop('disabled', true);

					break;
				case 'close_min_duration':

					var $div = $('#div_min_duration');
					$div.find('h2').css('color', '#ccc');

					$('#div_toggle_min_duration').empty();
					$('#div_toggle_min_duration').html('<img src="images/hyphen.png" class="open" id="open_min_duration" />');

					var $txt = $div.find('input');
					$txt.prop('disabled', true);

					break;
				case 'close_seeDetails':

					var $div = $('#div_seeDetails');
					$div.find('h2').css('color', '#ccc');

					$('#div_toggle_seeDetails').empty();
					$('#div_toggle_seeDetails').html('<img src="images/hyphen.png" class="open" id="open_seeDetails" />');

					$div.find('.bootstrap-switch').css('display', 'none');

					break;
				case 'close_startDate':

					var $div = $('#div_startDate');
					$div.find('h2').css('color', '#ccc');

					$('#div_toggle_startDate').empty();
					$('#div_toggle_startDate').html('<img src="images/hyphen.png" class="open" id="open_startDate" />');

					var $txt = $div.find('input');
					$txt.prop('disabled', true);

					break;
				case 'close_endDate':

					var $div = $('#div_endDate');
					$div.find('h2').css('color', '#ccc');

					$('#div_toggle_endDate').empty();
					$('#div_toggle_endDate').html('<img src="images/hyphen.png" class="open" id="open_endDate" />');

					var $txt = $div.find('input');
					$txt.prop('disabled', true);

					break;
			}

			bindOpen();
		});

	}

	function bindOpen() {

		$('.open').click(function () {

			var id = $(this).attr('id');

			switch (id) {
				case 'open_min_sets':

					var $div = $('#div_min_sets');
					$div.find('h2').css('color', '#000');

					$('#div_toggle_min_sets').empty();
					$('#div_toggle_min_sets').html('<img src="images/close.png" class="close" id="close_min_sets" />');

					var $txt = $div.find('input');
					$txt.prop('disabled', false);

					break;
				case 'open_min_reps':

					var $div = $('#div_min_reps');
					$div.find('h2').css('color', '#000');

					$('#div_toggle_min_reps').empty();
					$('#div_toggle_min_reps').html('<img src="images/close.png" class="close" id="close_min_reps" />');

					var $txt = $div.find('input');
					$txt.prop('disabled', false);

					break;
				case 'open_min_weight':

					var $div = $('#div_min_weight');
					$div.find('h2').css('color', '#000');

					$('#div_toggle_min_weight').empty();
					$('#div_toggle_min_weight').html('<img src="images/close.png" class="close" id="close_min_weight" />');

					var $txt = $div.find('input');
					$txt.prop('disabled', false);

					break;
				case 'open_min_duration':

					var $div = $('#div_min_duration');
					$div.find('h2').css('color', '#000');

					$('#div_toggle_min_duration').empty();
					$('#div_toggle_min_duration').html('<img src="images/close.png" class="close" id="close_min_duration" />');

					var $txt = $div.find('input');
					$txt.prop('disabled', false);

					break;
				case 'open_seeDetails':

					var $div = $('#div_seeDetails');
					$div.find('h2').css('color', '#000');

					$('#div_toggle_seeDetails').empty();
					$('#div_toggle_seeDetails').html('<img src="images/close.png" class="close" id="close_seeDetails" />');

					$div.find('.bootstrap-switch').css('display', 'block');

					break;
				case 'open_startDate':

					var $div = $('#div_startDate');
					$div.find('h2').css('color', '#000');

					$('#div_toggle_startDate').empty();
					$('#div_toggle_startDate').html('<img src="images/close.png" class="close" id="close_startDate" />');

					var $txt = $div.find('input');
					$txt.prop('disabled', false);

					break;
				case 'open_endDate':

					var $div = $('#div_endDate');
					$div.find('h2').css('color', '#000');

					$('#div_toggle_endDate').empty();
					$('#div_toggle_endDate').html('<img src="images/close.png" class="close" id="close_endDate" />');

					var $txt = $div.find('input');
					$txt.prop('disabled', false);

					break;
			}

			bindClose();
		});

	}

	function showSaveButton() {

		if (
			($('.sel_workoutTypes option:selected').text() != 'Select One')
			&& (bodyPartsSelected())
			&& (app.notNullOrZero($('#min_bodyPartImpact').val()))
			&& (app.notNullOrZero($('#timePerWI').val()))) {

			$('.saveButton').css('display', 'block');

		} else {

			if ($('#min_bodyPartImpact').val() == '0' && app.workoutTypeRule.workoutTypeRuleObj.changing_min_bodyPartImpact == true) {
				showModal('Error!', 'Minimum Body Part Impact must be greater than 0!');
			}

			if ($('#timePerWI').val() == '0' && app.workoutTypeRule.workoutTypeRuleObj.changing_timePerWI == true) {
				showModal('Error!', 'Times Per WI must be greater than 0!');
			}

			$('.saveButton').css('display', 'none');

		}

	}

	function unselectBodyPart(bodyPartToRemove) {
		app.workoutTypeRule.workoutTypeRuleObj.selectedBodyParts = jQuery.grep(app.workoutTypeRule.workoutTypeRuleObj.selectedBodyParts, function (value) {
			return value != bodyPartToRemove;
		});
	}

	function bodyPartsSelected() {
		if (app.workoutTypeRule.workoutTypeRuleObj.selectedBodyParts.length == 0)
			return false;
		return true;
	}

	function showModal(title, text) {
		$('#modalTitle').html('');
		$('#modalTitle').html(title);
		$('#modalText').html('');
		$('#modalText').html(text);

		$(".workoutTypeRule_ModalView").data("kendoMobileModalView").open();
	}

	function returnToWorkoutRuleTypeInterstatial() {
		app.hideFooterButton();
		app.mobileApp.navigate('modules/settings/workout/workoutTypeRuleInterstatial/workoutTypeRuleInterstatialIndex.html');
	}

})(app.workoutTypeRule);

// END_CUSTOM_CODE_settings