'use strict';

app.workoutTypeRuleInterstatial = kendo.observable({
	onShow: function () { },
	afterShow: function () { },
	workoutTypeRuleInterstatialObj: {
		data: {
			url: 'http://api.cognitivegenerationenterprises.com/api/userSettings/WorkoutType/GetRules/' + app.userSettings.UserName
		},
		e: {},

	}
});

// START_CUSTOM_CODE_settings
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {
	var initData = null;
	var listLoaded = true;
	var dataProvider = app.workoutTypeRuleInterstatial.workoutTypeRuleInterstatialObj.data,
        fetchFilteredData = function (paramFilter, searchFilter) {
        	var model = parent.get('workoutTypeRuleInterstatialModel'),
                dataSource = model.get('dataSource');

        	if (paramFilter) {
        		model.set('paramFilter', paramFilter);
        	} else {
        		model.set('paramFilter', undefined);
        	}

        	if (paramFilter && searchFilter) {
        		dataSource.filter({
        			logic: 'and',
        			filters: [paramFilter, searchFilter]
        		});
        	} else if (paramFilter || searchFilter) {
        		dataSource.filter(paramFilter || searchFilter);
        	} else {
        		dataSource.filter({});
        	}

        	initData = dataSource._pristineData;
        },
        dataSourceOptions = {
        	type: 'json',
        	transport: {
        		read: {
        			url: dataProvider.url
        		}
        	},
        	serverFiltering: true,
        },
        dataSource = new kendo.data.DataSource(dataSourceOptions),
        workoutTypeRuleInterstatialModel = kendo.observable({
        	dataSource: dataSource
        });

	parent.set('workoutTypeRuleInterstatialModel', workoutTypeRuleInterstatialModel);

	parent.set('onShow', function (e) {
		var param = e.view.params.filter ? JSON.parse(e.view.params.filter) : null,
            isListmenu = false,
            backbutton = e.view.element && e.view.element.find('header [data-role="navbar"] .backButtonWrapper');

		if (param || isListmenu) {
			backbutton.show();
			backbutton.css('visibility', 'visible');
		} else {
			if (e.view.element.find('header [data-role="navbar"] [data-role="button"]').length) {
				backbutton.hide();
			} else {
				backbutton.css('visibility', 'hidden');
			}
		}
		var a = app.userSettings.UserName;

		fetchFilteredData(param);
	});

	parent.set('afterShow', function (e) {

		app.hideFooterButtons();

		updateUI();

		setEventListeners();

		app.mobileApp.hideLoading();

	});

	function updateUI() {
		app.showFooterButton('images/add.png', addWorkoutRule);
	}

	function setEventListeners() { }

	function addWorkoutRule() {
		app.hideFooterButton();
		app.mobileApp.navigate('modules/settings/workout/workoutTypeRule/workoutTypeRuleIndex.html');
	}

	parent.set('workoutRuleClick', function (id) {

		app.workoutTypeRule.workoutTypeRuleObj.editOrView = true;
		app.workoutTypeRule.workoutTypeRuleObj.id = id;

		app.mobileApp.navigate('modules/settings/workout/workoutTypeRule/workoutTypeRuleIndex.html');
		
	});

})(app.workoutTypeRuleInterstatial);

// END_CUSTOM_CODE_settings