'use strict';

app.workoutType = kendo.observable({
	onShow: function () { },
	afterShow: function () { },
	workoutTypeObj: {
		data: { url: 'http://api.cognitivegenerationenterprises.com/api/userSettings/WorkoutTypes/' + app.userSettings.UserName },
		e: {}
	}
});

// START_CUSTOM_CODE_settings
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {
	var initData = null;
	var listLoaded = true;
	var dataProvider = app.workoutType.workoutTypeObj.data,
		fetchFilteredData = function (paramFilter, searchFilter) {
			var model = parent.get('workoutTypeModel'),
				dataSource = model.get('dataSource');

			if (paramFilter) {
				model.set('paramFilter', paramFilter);
			} else {
				model.set('paramFilter', undefined);
			}

			if (paramFilter && searchFilter) {
				dataSource.filter({
					logic: 'and',
					filters: [paramFilter, searchFilter]
				});
			} else if (paramFilter || searchFilter) {
				dataSource.filter(paramFilter || searchFilter);
			} else {
				dataSource.filter({});
			}

			initData = dataSource._pristineData;
		},
		dataSourceOptions = {
			type: 'json',
			transport: {
				read: {
					url: dataProvider.url
				}
			},
			serverFiltering: true,
		},
		dataSource = new kendo.data.DataSource(dataSourceOptions),
		workoutTypeModel = kendo.observable({
			dataSource: dataSource
		});

	parent.set('workoutTypeModel', workoutTypeModel);

	parent.set('onShow', function (e) {
		app.workoutType.workoutTypeObj.e = e;
		console.log('workout types onShow...');
		var param = e.view.params.filter ? JSON.parse(e.view.params.filter) : null,
			isListmenu = false,
			backbutton = e.view.element && e.view.element.find('header [data-role="navbar"] .backButtonWrapper');

		if (param || isListmenu) {
			backbutton.show();
			backbutton.css('visibility', 'visible');
		} else {
			if (e.view.element.find('header [data-role="navbar"] [data-role="button"]').length) {
				backbutton.hide();
			} else {
				backbutton.css('visibility', 'hidden');
			}
		}
		var a = app.userSettings.UserName;

		fetchFilteredData(param);

	});

	parent.set('afterShow', function (e) {

		app.hideFooterButtons();

		updateUI();

		setEventListeners();

		app.mobileApp.hideLoading();

	});

	function updateUI() {
		var objArray = [];
		objArray.push({ buttonPath: 'images/add.png', callback: app.workoutType.addNewWorkoutType });
		objArray.push({ buttonPath: 'images/rule-2.png', callback: app.workoutType.returnToWorkoutTypeRule });
		app.showFooterButtons(objArray);
	}

	function setEventListeners() {

		$('#addNewWorkoutType').click(function () {
			window.location.href = '#addNewWorkoutType';
		});

		$('.addButton').click(function () {
			var newWorkoutType = $('#newWorkoutType').val();
			app.ajaxPost('http://api.cognitivegenerationenterprises.com/api/userSettings/WorkoutType',
				{
					WorkoutTypeName: newWorkoutType,
					UserName: app.userSettings.UserName
				},
				function (response) {
					window.location.href = '#workoutTypeIndex_View';
				},
				function (errorReponse) {
					//TODO: Implmement.  Here I may want to show a frieldly error message using a modal
				}
			);
			// function (url, obj, callback, onError)
		});

	}

	parent.set('displayWorkoutTypes', function (respone) { });

	parent.set('makeNonVisible', function (id) {
		app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/userSettings/WorkoutTypes/Deactivate/' + app.userSettings.UserName + '/' + id, getMakeNonVisible_onSuccess, getMakeNonVisible_onError);
	});

	function getMakeNonVisible_onSuccess(response) {
		app.workoutType.onShow(app.workoutType.workoutTypeObj.e);
	}

	function getMakeNonVisible_onError(response) {
		console.log('Error diactivating workout type: ' + response);
	}

	parent.set('makeVisible', function (id) {
		app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/userSettings/WorkoutTypes/Activate/' + app.userSettings.UserName + '/' + id, getMakeVisible_onSuccess, getMakeVisible_onError);
	});

	function getMakeVisible_onSuccess(response) {
		app.workoutType.onShow(app.workoutType.workoutTypeObj.e);
	}

	function getMakeVisible_onError(response) {
		console.log('Error diactivating workout type: ' + response);
	}

	parent.set('delete', function (id) {
		app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/userSettings/WorkoutType/Delete/' + id + '/' + app.userSettings.UserName, getDelete_onSuccess, getDelete_onError);
	});

	function getDelete_onSuccess(response) {
		app.workoutType.onShow(app.workoutType.workoutTypeObj.e);
	}

	function getDelete_onError(response) {
		console.log('Error deleting workout type: ' + response);
	}

	parent.set('addNewWorkoutType', function () {

		app.mobileApp.hideLoading();

		// what's going on here? post to Stack Overflow
		//$('.newWorkoutType').focus(function (e) {
		//	//debugger;
		//	e.preventDefault();
		//	e.stopPropagation();
		//});

		window.location.href = '#addNewWorkoutType';

	});

	parent.set('returnToWorkoutTypeRule', function () {
		app.hideFooterButtons();
		app.mobileApp.navigate('modules/settings/workout/workoutTypeRule/workoutTypeRuleIndex.html');
	});

})(app.workoutType);

// END_CUSTOM_CODE_settings