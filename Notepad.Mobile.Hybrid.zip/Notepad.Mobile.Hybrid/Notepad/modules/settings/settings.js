'use strict';

app.settings = kendo.observable({
	onShow: function () { },
	afterShow: function () { },
	settingsObj: {}
});

// START_CUSTOM_CODE_settings
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {

	parent.set('onShow', function (e) { });

	parent.set('afterShow', function (e) { });

	parent.set('workout', function (e) {
		app.mobileApp.navigate("modules/settings/workout/workoutIndex.html");
	});

})(app.settings);

// END_CUSTOM_CODE_settings