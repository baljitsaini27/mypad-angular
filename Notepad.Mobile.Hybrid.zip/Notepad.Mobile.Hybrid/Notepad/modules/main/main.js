'use strict';

app.main = kendo.observable({
	afterShow: function () { },
	onShow: function () { },
	ui: {
		rebind: function () {

		}
	}
});

// START_CUSTOM_CODE_home
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {
	parent.set('afterShow', function (e) { });
	parent.set('onShow', function (e) { });
})(app.main);

// END_CUSTOM_CODE_home