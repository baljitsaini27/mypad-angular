    'use strict';
app.physicalActivity = kendo.observable({
	onShow: function () { },
	afterShow: function () {
		var title = app.physicalActivity.physicalActivityObj.title;
		$("#navbar").data("kendoMobileNavBar").title(title);
	},
	physicalActivityObj: {
		title: ''
	}
});

// START_CUSTOM_CODE_weighIn
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {
	parent.set('function_name', function (e) {
		// code here
	});
})(app.physicalActivity);

// END_CUSTOM_CODE_weighIn