'use strict';
app.workout = kendo.observable({
	onShow: function () { },
	afterShow: function () { },
	workoutObj: {
		Developer: 'Robert',
		Location: 'Idaho Falls, ID',
		SelectedBodyPart: 'null',
		SelectedAction: 'null',
		SelectedActionId: 'null',
		Display: '',
		PhysicalEntryId: null,
		isRandom: false,
		randomExerciseObj: {
			BodyPart: '',
			ExerciseName: '',
			Reps: 0,
			Weight: 0
		},
		DaysSince: 7
	}
});

// START_CUSTOM_CODE_weighIn
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {

	parent.set('onShowRepsAndWeight', function (e) {
		$('#reps').val('');
		$('#weight').val('');
		$('#reps').focus();
	});

	parent.set('onShow', function (e) { });

	parent.set('afterShow', function (e) {

		app.hideFooterButtons();

		setEventListeners();

		if (app.timer.timerObj.complete == true) {
			setTimeout(function () {
				if (app.workout.workoutObj.ActivityType == 'exercise' || app.workout.workoutObj.ActivityType == 'random') {
					var objectToPost = {
						JISVJIALRAVL: true,
						BodyPart: null,
						Distance: null,
						Duration: null,
						EndTimeString: null,
						ExerciseName: null,
						Id: app.workout.workoutObj.PhysicalEntryId,
						Reps: 9999,
						Weight: 9999,
						StartTimeString: null,
						Type: null,
						WorkoutName: null,
						UserName: app.userSettings.UserName
					};

					var json = JSON.stringify(objectToPost);

					$.ajax({
						url: 'http://api.cognitivegenerationenterprises.com/api/physicalEntry/end',
						type: 'POST',
						contentType: 'application/json; charset=utf-8',
						data: json,
						dataType: 'json',
						success: function (response) {
							window.location.href = '#repsAndWeight';
						},
						error: function (error) {
							// request failed
							console.log('error: ' + error);
						}
					});

				} else {
					app.workout.workoutObj.ActivityType = 'workout';
					app.workout.saveActivity();
				}

			}, 10);
		}

		getBodyPartOverview();

		app.mobileApp.hideLoading();
	});

	function setEventListeners() {
		console.log('set event listeners');	
		$('.daysSinceSubtract').click(function () {

			app.workout.workoutObj.DaysSince = app.workout.workoutObj.DaysSince - 1;
console.log('daysSinceSubtract ' + app.workout.workoutObj.DaysSince);	
			daysSinceSpanClickHandler();
		});

		$('.daysSinceAdd').click(function () {

			app.workout.workoutObj.DaysSince = app.workout.workoutObj.DaysSince + 1;
console.log('daysSinceAdd ' + app.workout.workoutObj.DaysSince);	
			daysSinceSpanClickHandler();
		});

		$('.daysSinceExcludeToday').click(function () {

			app.workout.workoutObj.DaysSince = app.workout.workoutObj.DaysSince + 1;
console.log('daysSinceExcludeToday ' + app.workout.workoutObj.DaysSince);	
			daysSinceExcludeTodaySpanClickHandler();
		});

	}

	parent.set('start', function (e) {

		var data = e.button.data();
		var activity = data.activity;

		switch (activity) {
			case 'random':
				app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/physicalEntry/getRandomPhysicalEntryExercise', getRandomPhysicalEntryExercise_onSuccess, getRandomPhysicalEntryExercise_onError);
				break;
			case 'backalignment':
				break;
			case 'chestsqueezes':
				app.physicalActivity.physicalActivityObj.title = 'Chest Squeezes';
				break;
			case 'jog':
				app.physicalActivity.physicalActivityObj.title = 'Jog';
				break;
			case 'resistancesmall':
				app.physicalActivity.physicalActivityObj.title = 'Resistance (Sm)';
				break;
			case 'resistancelarge':
				app.physicalActivity.physicalActivityObj.title = 'Resistance (Lg)';
				break;
			case 'stretch':
				app.physicalActivity.physicalActivityObj.title = 'Stretch';
				break;
			case 'weights':
				window.location.href = '#bodyParts';
				break;
			case 'backalignment':
				app.acHome.workoutActivityObj.title = 'Back Alignment';
				app.acHome.updateTitle();
				app.mobileApp.navigate('modules/prototyping/workout_activity/activityIndex.html');
				break;
		}

		app.workout.workoutObj.ActivityType = activity;

		if (activity != 'weights' && activity != 'random') {
			app.workout.workoutObj.SelectedActionId = null;
			app.mobileApp.navigate('components/ui/timer/timerActivity.html');
		}

	});

	function getRandomPhysicalEntryExercise_onSuccess(response) {

		// queue up correct exercise
		app.workout.workoutObj.isRandom = true;
		// BodyPart
		app.workout.workoutObj.randomExerciseObj.BodyPart = response.BodyPart;
		// ExerciseName
		app.workout.workoutObj.randomExerciseObj.ExerciseName = response.ExerciseName;
		// Reps
		app.workout.workoutObj.randomExerciseObj.Reps = response.Reps;
		// Weight
		app.workout.workoutObj.randomExerciseObj.Weight = response.Weight;

		app.workout.workoutObj.Display = '<strong>Body Part:</strong> ' + response.BodyPart + '<br/>';
		app.workout.workoutObj.Display += '<strong>Exercise:</strong> ' + response.ExerciseName + '<br/>';
		app.workout.workoutObj.Display += '<strong>Reps:</strong> ' + response.Reps + '<br/>';

		if (response.Weight != 0) {
			app.workout.workoutObj.Display += '<strong>Weight:</strong> ' + response.Weight + '<br/>';
		}

		app.mobileApp.navigate('components/ui/timer/timerRandomExercise.html');
	}

	function getRandomPhysicalEntryExercise_onError(response) {
		console.log('Error getting random exercise: ' + response);
	}

	parent.set('getActivity', function (e) {

		var data = e.button.data();
		app.workout.workoutObj.SelectedBodyPart = data.bodypart;

		app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/exercise/getBodyPartHistory/' + app.userSettings.UserName + '/' + data.bodypart, getBodyPartHistory_onSuccess, getBodyPartHistory_onError);

	});

	function getBodyPartHistory_onSuccess(response) {

		var output = '<div class="container">';

		for (var i = 0; i < response.length; i++) {
			output += '<div class="row">';
			output += '<div class="col-xs-6"><b>' + response[i].ExerciseName + '</b><br style="clear:both;" />' + response[i].EndTimeString + '</div>';
			output += '<div class="col-xs-2">' + ((response[i].Reps == 0 || response[i].Reps == '0') ? '-' : response[i].Reps
				+ ' reps') + ' </div>';
			output += '<div class="col-xs-2">' + ((response[i].Weight == 0 || response[i].Weight == '0') ? '-' : response[i].Weight + ' lbs') + '</div>';
			output += '<div class="col-xs-2">' + response[i].Duration + '</div>';
			output += '</div>';
			output += '<hr/>';
		}

		output += '</div>';

		$('.bodyPartHistory').html(output);
		kendo.bind($('.bodyPartHistory'), app.workout, kendo.mobile.ui);

		app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/workout/getBodyPartWorkouts/' + app.workout.workoutObj.SelectedBodyPart, getBodyPartWorkouts_onSuccess, getBodyPartWorkouts_onError);

	}

	function getBodyPartWorkouts_onSuccess(response) {

		var string = '';

		for (var i = 0; i < response.length; i++) {
			string += '<button data-role="button" class="button" data-bind="click: startWorkout" data-activity="' + response[i].WorkoutName + '" data-id="' + response[i].WorkoutId + '">' + response[i].WorkoutName + '</button><br/><br/>';
		}

		string += '<button data-role="button" class="button" data-bind="click: getIndividualExercises" data-activity="IndividualExercise">Individual Exercise</button><br/><br/>';

		$('#div_select_activity').html(string);
		kendo.bind($('#div_select_activity'), app.workout, kendo.mobile.ui);

		window.location.href = '#selectActivity';

	}

	function getBodyPartWorkouts_onError(response) { }

	function getBodyPartHistory_onError(response) {
		console.log('Error getting body part history: ' + response);
	}

	parent.set('getIndividualExercises', function (e) {

		app.workout.workoutObj.SelectedAction = 'IndividualExercise';

		app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/workout/getBodyPartExercises/' + app.workout.workoutObj.SelectedBodyPart, getBodyPartExercises_onSuccess, getBodyPartExercises_onError);

	});

	function getBodyPartExercises_onSuccess(response) {

		var string = '';

		for (var i = 0; i < response.length; i++) {
			string += '<button data-role="button" class="button" data-bind="click: startExercise" data-activity="' + response[i].ExerciseName + '" data-id="' + response[i].ExerciseId + '">' + response[i].ExerciseName + '</button><br/><br/>';
		}

		$('#div_select_exercise').html(string);
		kendo.bind($('#div_select_exercise'), app.workout, kendo.mobile.ui);

		window.location.href = '#selectExercise';

	}

	function getBodyPartExercises_onError(response) {
		console.log('error: ' + error);
	}

	parent.set('startWorkout', function (e) {

		app.endTimer();

		var data = e.button.data();

		app.workout.workoutObj.SelectedAction = data.activity;
		app.workout.workoutObj.SelectedActionId = data.id;
		app.workout.workoutObj.ActivityType = 'workout';
		app.workout.workoutObj.Display = data.activity;

		app.mobileApp.navigate('components/ui/timer/timerWorkout.html');

	});

	parent.set('startExercise', function (e) {

		app.endTimer();

		if (e != 'REDO' && e != 'NEW') {

			var data = e.button.data();

			app.workout.workoutObj.SelectedAction = data.activity;
			app.workout.workoutObj.SelectedActionId = data.id;
			app.workout.workoutObj.ActivityType = 'exercise';
			app.workout.workoutObj.Display = data.activity;

			app.mobileApp.navigate('components/ui/timer/timerExercise.html');

		} else {

			if (e == 'REDO') {

				$('.reps').val(app.workout.workoutObj.randomExerciseObj.Reps);
				$('.weight').val('');
				$('.reps').focus();

				app.mobileApp.navigate('components/ui/timer/timerExercise.html');

			}

			if (e == 'NEW') {

				$('.reps').val('');
				$('.weight').val('');
				$('.reps').focus();

				app.workout.getIndividualExercises(null);

				app.mobileApp.navigate('modules/workout/workoutIndex.html');
			}

		}

	});

	parent.set('saveActivity', function (e) {

		app.mobileApp.showLoading();

		if (app.workout.workoutObj.ActivityType == 'workout') {

			var objectToPost = {
				JISVJIALRAVL: true,
				BodyPart: null,
				Distance: null,
				Duration: null,
				EndTimeString: null,
				ExerciseName: null,
				Id: app.workout.workoutObj.PhysicalEntryId,
				Reps: 9999,
				Weight: 9999,
				StartTimeString: null,
				Type: null,
				WorkoutName: null,
				UserName: app.userSettings.UserName
			};

			app.ajaxPost('http://api.cognitivegenerationenterprises.com/api/physicalEntry/end', objectToPost, workout_postEndPhysicalEntry_onSuccess, workout_postEndPhysicalEntry_onError);

		}

		if (app.workout.workoutObj.ActivityType == 'exercise' || app.workout.workoutObj.ActivityType == 'random') {
            
			var objectToPost = {
				JISVJIALRAVL: true,
				BodyPart: null,
				Distance: null,
				Duration: null,
				EndTimeString: null,
				ExerciseName: null,
				Id: app.workout.workoutObj.PhysicalEntryId,
				Reps: this.reps,
				StartTimeString: null,
				Type: null,
				WorkoutName: null,
				Weight: this.weight,
				UserName: app.userSettings.UserName
			};

			if (objectToPost.Weight == null)
				objectToPost.Weight = 0;

			app.ajaxPost('http://api.cognitivegenerationenterprises.com/api/physicalEntry/end', objectToPost, exercise_postEndPhysicalEntry_onSuccess, exercise_postEndPhysicalEntry_onError);

		}

	});

	function workout_postEndPhysicalEntry_onSuccess(response) {
		app.workout.workoutObj.ActivityType = undefined;
		app.timer.timerObj.complete = false;
		app.timer.timerObj.duration = '';
		app.mobileApp.navigate('modules/activity/activityIndex.html');
	}

	function workout_postEndPhysicalEntry_onError(response) {
		console.log('Error ending physical entry: ' + response);
	}

	function exercise_postEndPhysicalEntry_onSuccess(response) {

		app.workout.workoutObj.ActivityType = undefined;
		app.timer.timerObj.complete = false;
		app.timer.timerObj.duration = '';

		$('.reps').val('');
		$('.weight').val('');

		app.mobileApp.navigate('modules/activity/activityIndex.html');
	}

	function exercise_postEndPhysicalEntry_onError(response) {
		console.log('Error ending physical entry: ' + response);
	}

	function getBodyPartOverview(e) {
		app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/physicalEntry/getBodyPartOverview/' + app.workout.workoutObj.DaysSince + '/' + app.userSettings.UserName, getBodyPartOverview_onSuccess, getBodyPartOverview_onError);
	}

	function getBodyPartOverview_onSuccess(response) {
		renderBodyPartOverview(response);
	}

	function getBodyPartOverview_onError(response) {
		Console.log('Error getting body part overview: ' + response);
	}

	function renderBodyPartOverview(response) {
		$('.bodyPartOverview').html('');
		kendo.bind($('.bodyPartOverview'), app.workout, kendo.mobile.ui);

		var output = '<center><table><col align="left"><col align="left"><col align="left">';

		for (var i = 0; i < response.length; i++) {
			var daysSince = response[i].DaysSince;

			var daysAgoText = daysSince == 0 ? '(today)' : daysSince == -1 ? '(earlier)' : daysSince == 1 ? '(yesterday)' : '(' + daysSince + ' days ago)';
			if (response[i])
				output += '<tr><td><b>' + response[i].BodyPart + '</b> <i>' + daysAgoText + '</i><br style="clear:both;"/>' + response[i].LastDate + '</td><td>' + response[i].Duration + '</td><td>' + response[i].Sets + ' sets</td></tr>';
		}
		output += '</table></center>';

		$('.bodyPartOverview').html(output);
		kendo.bind($('.bodyPartOverview'), app.workout, kendo.mobile.ui);
	}

	function daysSinceSpanClickHandler() {

		$('.daysSince').html(app.workout.workoutObj.DaysSince);
		kendo.bind($('.daysSince'), app.workout, kendo.mobile.ui);

		app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/physicalEntry/getBodyPartOverview/' + app.workout.workoutObj.DaysSince + '/' + app.userSettings.UserName, getBodyPartOverview_onSuccess, getBodyPartOverview_onError);

	}

	function daysSinceExcludeTodaySpanClickHandler() {

		$('.daysSince').html(app.workout.workoutObj.DaysSince);
		kendo.bind($('.daysSince'), app.workout, kendo.mobile.ui);

		app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/physicalEntry/GetBodyPartOverviewExcludeToday/' + app.workout.workoutObj.DaysSince + '/' + app.userSettings.UserName, getBodyPartOverview_onSuccess, getBodyPartOverview_onError);

	}

})(app.workout);

// END_CUSTOM_CODE_weighIn