'use strict';

app.physicalActivity = kendo.observable({
	onShow: function () { },
	afterShow: function () { },
	physicalActivityObj : {
		title: '',
		complete: false
	},
	getProps : function () {

		var result = {};

		switch (app.physicalActivity.title) {
			case 'Back Alignment':
				result = {
					APIUrl: '',
					onCompletePromise: null,
					components: { timer: true, numberPad: null }
				};
				break;
			case 'Chest Squeezes':
				result = {
					APIUrl: '',
					onCompletePromise: null,
					components: { timer: true, numberPad: { title: 'Enter Reps' } }
				};
				break;
			case 'Jog':
				result = {
					APIUrl: '',
					onCompletePromise: null,
					components: { timer: true, numberPad: { title: 'Enter Distance' } }
				};
				break;
			case 'Resistance (Sm)':
				result = {
					APIUrl: '',
					onCompletePromise: null,
					components: { timer: true, numberPad: null }
				};
				break;
			case 'Resistance (Lg)':
				result = {
					APIUrl: '',
					onCompletePromise: null,
					components: { timer: true, numberPad: null }
				};
				break;
			case 'Stretch':
				result = {
					APIUrl: '',
					onCompletePromise: null,
					components: { timer: true, numberPad: null }
				};
				break;
		}

		return result;

	}
});

// START_CUSTOM_CODE_physicalActivity
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {

	parent.set('onShow', function (e) { });

	parent.set('afterShow', function (e) {

		app.hideFooterButtons();

		updateUI();

		if (app.physicalActivity.physicalActivityObj.complete == true) {

			var startObj = {
				JISVJIALRAVL: true,
				BodyPart: null,
				Distance: null,
				Duration: null,
				ExerciseName: null,
				Reps: null,
				Type: null,
				UserName: app.userSettings.UserName,
				Weight: null,
				WorkoutName: null
			};

			var endObj = {
				JISVJIALRAVL: true,
				Id: null,
				UserName: app.userSettings.UserName
			};

			var endComplexObj = {
				JISVJIALRAVL: true,
				Id: null,
				BodyPart: null,
				Distance: null,
				Duration: null,
				ExerciseName: null,
				Reps: 0,
				Type: null,
				UserName: app.userSettings.UserName,
				Weight: 0,
				WorkoutName: null
			};

			switch (app.workout.workoutObj.ActivityType) {
				case 'backalignment':
					endObj.Id = app.workout.workoutObj.PhysicalEntryId;
					endObj.Reps = 9999;
					endObj.Weight = 9999;
					break;
				case 'chestsqueezes':
					window.location.href = '#reps';
					break;
				case 'jog':
					window.location.href = '#jog';
					break;
				case 'resistancesmall':
					endObj.Id = app.workout.workoutObj.PhysicalEntryId;
					endObj.Reps = 9999;
					endObj.Weight = 9999;
					break;
				case 'resistancelarge':
					endObj.Id = app.workout.workoutObj.PhysicalEntryId;
					endObj.Reps = 9999;
					endObj.Weight = 9999;
					break;
				case 'stretch':
					endObj.Id = app.workout.workoutObj.PhysicalEntryId;
					endObj.Reps = 9999;
					endObj.Weight = 9999;
					break;
			}

			if (app.workout.workoutObj.ActivityType != 'jog' && app.workout.workoutObj.ActivityType != 'chestsqueezes') {

				var finalObj = endObj;

				if (endObj.Id == null)
					finalObj = endComplexObj;

				ajax(finalObj);

			}

		}

		app.mobileApp.hideLoading();

	});

	function updateUI() {
		var title = app.physicalActivity.physicalActivityObj.title;
		$("#navbar").data("kendoMobileNavBar").title(title);
	}

	parent.set('saveChestSqueezees', function (e) {

		endComplexObj.Id = app.workout.workoutObj.PhysicalEntryId;
		endComplexObj.Reps = this.reps;
		
		ajax(endComplexObj);

	});

	parent.set('saveJog', function (e) {

		var obj = {
			JISVJIALRAVL: true,
			Distance: this.distance,
			Type: 'jog',
			Id: app.workout.workoutObj.PhysicalEntryId,
			UserName: app.userSettings.UserName
		};

		ajax(obj);

	});

	function ajax(obj) {

		app.mobileApp.showLoading();

		app.ajaxPost('http://api.cognitivegenerationenterprises.com/api/physicalEntry/end', obj, postPhysicalEntryEnd_onSuccess, postPhysicalEntryEnd_onError);

	}

	function postPhysicalEntryEnd_onSuccess(response){
		app.workout.workoutObj.ActivityType = undefined;
		app.timer.timerObj.complete = false;
		app.timer.timerObj.duration = '';

		this.reps = '';
		this.distance = '';

		// 9.13.16 addition, not sure... // do global check... is this neccessary here or even above?
		//app.physicalActivity.physicalActivityObj.complete = true;

		// 10.11.16 it may be... there has been small glitches that this may be an explaination for... 
		// (may need to psueducode it out?) (path...etc...) remember switching from Stretch to exercise... 
		// think about jogging during the morning, and the issues i have...

		app.mobileApp.navigate("modules/activity/activityIndex.html");
	}

	function postPhysicalEntryEnd_onError(response){
		console.log('Error ending physical activity: ' + error);
	}

})(app.physicalActivity);

// END_CUSTOM_CODE_physicalActivity