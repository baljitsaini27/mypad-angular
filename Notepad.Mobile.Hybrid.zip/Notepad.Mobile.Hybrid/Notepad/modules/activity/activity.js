'use strict';

app.activity = kendo.observable({
	onShow: function () { },
	afterShow: function () { },
	activityObj: {
		seed: 0,
		count: 500,
		workingOut: false
	}
});

// START_CUSTOM_CODE_activity
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {
	var initData = null;
	var listLoaded = true;
	
	var dataProvider = { url: 'http://api.cognitivegenerationenterprises.com/api/activity/getFeed/' + app.userSettings.UserName + '/0/500'},
        fetchFilteredData = function (paramFilter, searchFilter) {
        	//debugger;
        	var model = parent.get('activityModel'),
                dataSource = model.get('dataSource');

        	if (paramFilter) {
        		model.set('paramFilter', paramFilter);
        	} else {
        		model.set('paramFilter', undefined);
        	}

        	if (paramFilter && searchFilter) {
        		dataSource.filter({
        			logic: 'and',
        			filters: [paramFilter, searchFilter]
        		});
        	} else if (paramFilter || searchFilter) {
        		dataSource.filter(paramFilter || searchFilter);
        	} else {
        		dataSource.filter({});
        	}

        	initData = dataSource._pristineData;
        },
        dataSourceOptions = {
        	type: 'json',
        	transport: {
        		read: {
        			url: dataProvider.url
        		}
        	},
        	serverFiltering: true,
        },
        dataSource = new kendo.data.DataSource(dataSourceOptions),
        activityModel = kendo.observable({
        	dataSource: dataSource
        });

	parent.set('activityModel', activityModel);

	parent.set('onShow', function (e) {
		dataSource.transport.options.read.url = 'http://api.cognitivegenerationenterprises.com/api/activity/getFeed/' + app.userSettings.UserName + '/0/500';

		app.checkOpenActivity();

		var param = e.view.params.filter ? JSON.parse(e.view.params.filter) : null,
            isListmenu = false,
            backbutton = e.view.element && e.view.element.find('header [data-role="navbar"] .backButtonWrapper');

		if (param || isListmenu) {
			backbutton.show();
			backbutton.css('visibility', 'visible');
		} else {
			if (e.view.element.find('header [data-role="navbar"] [data-role="button"]').length) {
				backbutton.hide();
			} else {
				backbutton.css('visibility', 'hidden');
			}
		}

		fetchFilteredData(param);

		attachToScroller(e);

	});

	parent.set('afterShow', function (e) {

		app.hideFooterButtons();

		app.activity.activityObj.workingOut = true;

		updateUI();

		app.mobileApp.hideLoading();

		return;
		updateNotifcation();
	});

	function updateUI() {
		$('#li_weighIn').removeClass('active');
		$('#li_eat').removeClass('active');
		$('#li_workout').removeClass('active');
		$('#li_activityFeed').addClass('active');
	}

	function attachToScroller(e) {
		var scroller = e.view.scroller;

		scroller.bind("scroll", function (e) {
			var a = e.sender;
			var b = a.dimensions;
			var c = b.y;
			var d = c.min;
			var max = d * -1;
			var curr = e.scrollTop;
			var pct = (curr / max) * 100;
			if (pct >= 50) {
				loadMore(e);
			}
			console.log('pct: ' + pct + '%');
		});
	}

	function loadMore(e) {
		parent.listLoaded = false;
		app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/activity/getFeed/' + app.userSettings.UserName + '/' + app.activity.activityObj.seed + '/' + app.activity.activityObj.count
			, getActivityFeed_onSuccess
			, getActivityFeed_onError);
	}

	function getActivityFeed_onSuccess(response) {

		app.activity.activityObj.seed += app.activity.activityObj.count;

		for (var i = 0; i < response.length; i++) {
			response.Type = (app.activity.activityObj.seed + i) + response.Type;
			dataSource._pristineData.push(response[i]);
			dataSource._data.push(response[i]);
			dataSource._view.push(response[i]);
			dataSource._pristineTotal = dataSource._pristineData.length;
			dataSource._total = dataSource._pristineTotal;
		}

		parent.listLoaded = true;

	}

	function getActivityFeed_onError(response) {
		console.log('Error getting activity feed: ' + error);
	}

	parent.set('endWorkouts', function () {
		app.activity.activityObj.workingOut = false;
	});

	parent.set('redoExercise', function (exerciseId, reps, weight) {
        //alert('exerciseId: ' + exerciseId + '\nreps: ' + reps + '\nweight: ' + weight);
		app.endTimer();

		app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/exercise/' + exerciseId, function (response) {

			app.workout.workoutObj.SelectedAction = response.ExerciseName;
			app.workout.workoutObj.SelectedActionId = response.ExerciseId;
			app.workout.workoutObj.ActivityType = 'exercise';
			app.workout.workoutObj.Display = response.ExerciseName;
			app.workout.workoutObj.randomExerciseObj.Reps = reps == 15 ? 12 : reps == 12 ? 8 : reps == 8 ? 15 : '';
			app.workout.startExercise('REDO');

		}, getExercise_onError);
	});

	function getExercise_onError(response) {
		console.log('Error getting exercise: ' + error);
	}

	parent.set('newExercise', function (type) {
		app.endTimer();
		var exerciseName = type.split(':')[1];
		var exerciseNameBodyPart = exerciseName.split('-')[0];
		var bodyPart = exerciseNameBodyPart.trim();

		app.workout.workoutObj.SelectedBodyPart = bodyPart;
		app.workout.startExercise('NEW');
	});

	parent.set('startTimer', function (endTime) {

		var now = Date();
		var seconds = app.getDateDiff(endTime, now, 'seconds');
		var hours = app.getDateDiff(endTime, now, 'hours');
		var minutes = app.getDateDiff(endTime, now, 'minutes');
		var actuallMinsDiff = minutes - (hours * 60);
		var hoursInSeconds = hours * 60 * 60;
		var runningSeconds = seconds - hoursInSeconds;
		var minutesInSeconds = actuallMinsDiff * 60;

		runningSeconds = runningSeconds - minutesInSeconds;

		app.setFinalDisplay(hours, actuallMinsDiff, runningSeconds);

	});

	function updateNotifcation(e) {
		app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/meal/getLastMeal/' + app.userSettings.UserName, getLastMeal_onSuccess, getLastMeal_onError);

	}

	function getLastMeal_onSuccess(response) {

		var dateArray = response.EndTime.split('T');
		var timeArray = dateArray[1].split(':');
		var lastMealTime = new Date(dateArray[0]);
		var todayYear = lastMealTime.getFullYear();
		var todayMonth = lastMealTime.getMonth();
		var todayDay = lastMealTime.getDate() + 1;

		// if bugs, then it could be related to last day of month.  i think there may be issue here, not sure...
		lastMealTime = new Date(todayYear, todayMonth, todayDay);
		lastMealTime.setHours(timeArray[0], timeArray[1]);

		var diffMinutes = app.activity.getDateDiff(new Date(), lastMealTime, 'minutes');
		var minutesToNextMeal = 180 + diffMinutes;
		var nextReminder = new Date();

		nextReminder.setMinutes(nextReminder.getMinutes() + minutesToNextMeal);

		app.clearAllNotifications();

		// set another notification for the next meal
		// just set for 3 hours later if less than midnight and greater than 7 am
		var d = new Date();
		var hours = d.getHours();

		if (!app.activity.activityObj.workingOut) {
			app.toast('End...', function () {
				if (hours > 7) {
					cordova.plugins.notification.local.schedule({
						id: 1,
						title: '3 Hours Since Last Meal...',
						text: '... let\'s eat!',
						sound: app.userSettings.Sounds.railroad,
						badge: 3,
						every: 15,
						led: 'FF0000',
						autoClear: true,
						at: new Date(nextReminder)
					});

					app.toast('Set 3 hour reminder', function () {
						setTimeout(function () {
							app.mobileApp.navigate("modules/activity/activityIndex.html");
						}, 3000);
					});
				}
			});
		}

	}

	function getLastMeal_onError(response) {
		console.log('Error getting last meal: ' + error);
	}

})(app.activity);

// END_CUSTOM_CODE_activity