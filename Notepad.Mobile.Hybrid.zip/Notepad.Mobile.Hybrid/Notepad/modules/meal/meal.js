'use strict';
app.mealView = kendo.observable({
	onShow: function () { },
	afterShow: function () { }
});

app.eatView = kendo.observable({
	onShow: function () { },
	afterShow: function () { }
});

// START_CUSTOM_CODE_mealViewModel
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

var adding = false;

app.eatView = kendo.observable({
	onShow: function () { },
	afterShow: function () { },
});

(function (parent) {

	var dataProvider = app.data.meals,
		fetchFilteredData = function (paramFilter, searchFilter) {

			var model = parent.get('mealViewModel'),
				dataSource = model.get('dataSource');

			if (paramFilter) {
				model.set('paramFilter', paramFilter);
			} else {
				model.set('paramFilter', undefined);
			}

			if (paramFilter && searchFilter) {
				dataSource.filter({
					logic: 'and',
					filters: [paramFilter, searchFilter]
				});
			} else if (paramFilter || searchFilter) {
				dataSource.filter(paramFilter || searchFilter);
			} else {
				dataSource.filter({});
			}
		},
		dataSourceOptions = {
			type: 'json',
			transport: {
				read: {
					url: dataProvider.url
				}
			},
			serverFiltering: true,
		},
		dataSource = new kendo.data.DataSource(dataSourceOptions),
		mealViewModel = kendo.observable({
			dataSource: dataSource
		});

	parent.set('mealViewModel', mealViewModel);

	parent.set('onShow', function (e) {
		var param = e.view.params.filter ? JSON.parse(e.view.params.filter) : null,
			isListmenu = false,
			backbutton = e.view.element && e.view.element.find('header [data-role="navbar"] .backButtonWrapper');

		if (param || isListmenu) {
			backbutton.show();
			backbutton.css('visibility', 'visible');
		} else {
			if (e.view.element.find('header [data-role="navbar"] [data-role="button"]').length) {
				backbutton.hide();
			} else {
				backbutton.css('visibility', 'hidden');
			}
		}

		if (!adding) {
            
			app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/activity/getOpenActivity2/' + app.userSettings.UserName, function(response){
				// request succeeded
				if (response == 'Meal') {
					window.location.href = "#eat";
				} else {
					window.location.href = "#selectMealItems";
				}
			});
			/*
			$.ajax({
				url: 'http://api.cognitivegenerationenterprises.com/api/activity/getOpenActivity2/' + app.userSettings.UserName,
				type: 'GET',
				contentType: 'application/json; charset=utf-8',
				success: function (response) {
					// request succeeded
					if (response == 'Meal') {
						window.location.href = "#eat";
					} else {
						window.location.href = "#selectMealItems";
					}
				},
				error: function (error) {
					// request failed
					console.log('Get Open activity error: ' + error);
				}
			});
            */
		}

		fetchFilteredData(param);
		fetchFilteredDataCurrentItems(param);
	});

	parent.set('afterShow', function (e) {

		app.hideFooterButtons();

		updateUI();

		app.mobileApp.hideLoading();

	});

	function updateUI() {

		$('#li_workout').removeClass('active');
		$('#li_eat').addClass('active');
		$('#li_activityFeed').removeClass('active');
		$('#li_weighIn').removeClass('active');

	}

	parent.set('end', function (e) {

		app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/meal/end/' + app.userSettings.UserName, getMealEnd_onSuccess, getMealEnd_onError);

	});

	function getMealEnd_onSuccess(response) {
		app.mobileApp.navigate("modules/home/view.html");
	}

	function getMealEnd_onError(response) {
		console.log('Error ending meal: ' + response);
	}

	parent.set('submit', function (e) {

		var objectToPost = {
			JISVJIALRAVL: true,
			EndTime: null,
			MealItem: {
				MealItemId: this.mealItemId.MealItemId,
				MealItemName: this.mealItemId.MealItemName
			},
			MealName: this.mealItemId.MealItemId,
			StartTime: null,
			UserName: app.userSettings.UserName,
			Weight: this.weight
		};

		app.ajaxPost('http://api.cognitivegenerationenterprises.com/api/meal/mealEntry', objectToPost, postMealEntry_onSuccess, postMealEntry_onError);

	});

	function postMealEntry_onSuccess(response) {
		window.location.href = "#eat";
	}

	function postMealEntry_onError(response) {
		console.log('Error adding meal item:' + response);
	}

	// for later, will add ability to take picture of meal (meal item)
	//parent.set('takePicture', function (e) {
	//	var success = function (data) {
	//		everlive.Files.create({
	//			Filename: Math.random().toString(36).substring(2, 15) + ".jpg",
	//			ContentType: "image/jpeg",
	//			base64: data
	//		}).then(loadPhotos,
	//			function (err) {
	//				alert("Could not upload image" + err.message);
	//			});
	//	};
	//	var error = function () {
	//		navigator.notification.alert("Unfortunately we could not add the image");
	//	};
	//	var config = {
	//		destinationType: Camera.DestinationType.DATA_URL,
	//		targetHeight: 400,
	//		targetWidth: 400
	//	};
	//	navigator.camera.getPicture(success, error, config);
	//});

})(app.mealView);

(function (parent) {

	parent.set('onShow', function (e) {
		adding = false;
	});

	parent.set('end', function (e) {

		app.mobileApp.showLoading();

		app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/meal/end/' + app.userSettings.UserName, getMealEnd_onSuccess, getMealEnd_onError);

	});

	function getMealEnd_onSuccess(response){
		app.mobileApp.navigate("modules/activity/activityIndex.html");
	}

	function getMealEnd_onError(response){
		console.log('Error ending meal: ' + response);
	}

	parent.set('add', function (e) {
		adding = true;
	});

})(app.eatView);

// END_CUSTOM_CODE_mealViewModel