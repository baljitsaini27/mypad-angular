'use strict';
console.log('timer.js loaded');
app.timer = kendo.observable({
	onShow: function () { },
	afterShow: function () { },
	timerObj : {
		duration: '',
		complete: false
	}
});

// START_CUSTOM_CODE_weighIn
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

(function (parent) {
	console.log('timer.js function (parent)');
	var hours;
	var minutes;
	var seconds;
	var finalDisplay;
	var incrementer;
	var timer;

	parent.set('onShow', function (e) { });

	parent.set('afterShow', function (e) {
		debugger;
		app.hideFooterButtons();

		updateUI();

		setEventListeners();

		getHistory();

		app.mobileApp.hideLoading();

	});

	function updateUI() {

		var title = '';

		if (app.workout.workoutObj.ActivityType == 'backalignment') {
			title = 'Back Alignment';
		}

		if (app.workout.workoutObj.ActivityType == 'chestsqueezes') {
			title = 'Chest / Arms Squeezee';
		}

		if (app.workout.workoutObj.ActivityType == 'jog') {
			title = 'Jog';
		}

		if (app.workout.workoutObj.ActivityType == 'resistancesmall') {
			title = 'Resistance (Sm)';
		}

		if (app.workout.workoutObj.ActivityType == 'resistancelarge') {
			title = 'Resistance (Lg)';
		}

		if (app.workout.workoutObj.ActivityType == 'stretch') {
			title = 'Stretch';
		}

		if (title != '') {
			app.workout.workoutObj.Display = title;
			$('#navbar').data('kendoMobileNavBar').title(title);
		}

		$('.timerStopwatch').html('00:00:00');
		kendo.bind($('.timerStopwatch'), app.workout, kendo.mobile.ui);
		// kendo.bind($('.timerStopwatch'), app.workout, kendo.mobile.ui); // should this be app.timer ??
		// TODO: Test before finalizing!!!!!!

		$('.activityTitle').html(app.workout.workoutObj.Display);
		kendo.bind($('.activityTitle'), app.workout, kendo.mobile.ui);

		hours = '00';
		minutes = '00';
		seconds = '00';
		finalDisplay = '';
		timer = 0;

		$('.startTimer').css('display', 'block');

	}

	function setEventListeners() { }

	function getHistory() {
		if (app.workout.workoutObj.SelectedActionId == 'null' || app.workout.workoutObj.SelectedActionId == null) {
			app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/workout/getWorkoutHistory/' + app.userSettings.UserName + '/' + app.workout.workoutObj.ActivityType, getHistory_onSuccess, getHistory_onError);
		} else {
			app.ajaxGet('http://api.cognitivegenerationenterprises.com/api/exercise/getHistory/' + app.userSettings.UserName + '/' + app.workout.workoutObj.SelectedActionId, getHistory_onSuccess, getHistory_onError);
		}
	}

	function getHistory_onSuccess(response) {

		var output = '<div class="container">';

		for (var i = 0; i < response.length; i++) {
			output += '<div class="row">';
			output += '<div class="col-xs-3"><b>' + response[i].EndTimeString + '</b></div>';
			output += '<div class="col-xs-3">' + ((response[i].Reps == 0 || response[i].Reps == '0') ? '-' : response[i].Reps
				+ ' reps') + ' </div>';
			output += '<div class="col-xs-3">' + ((response[i].Weight == 0 || response[i].Weight == '0') ? '-' : response[i].Weight + ' lbs') + '</div>';
			output += '<div class="col-xs-3">' + response[i].Duration + '</div>';
			output += '</div>';
			output += '<hr/>';
		}

		output += '</div>';

		$('.exerciseHistory').html(output);
		kendo.bind($('.exerciseHistory'), app.timer, kendo.mobile.ui);

	}

	function getHistory_onError(response) {
		console.log('Error getting history: ' + response);
	}

	parent.set('back', function (e) {
		app.mobileApp.navigate("modules/workout/workoutIndex.html");
	});

	parent.set('startTimer', function (e) {

		app.currentView('timer');
		app.tick();

		$('.startTimer').css('display', 'none');
		$('.endTimer').css('display', 'block');

		var objectToPost = {
			JISVJIALRAVL: true,
			BodyPart: null,
			Distance: null,
			Duration: null,
			EndTimeString: null,
			ExerciseName: null,
			Reps: null,
			StartTimeString: null,
			Type: null,
			UserName: app.userSettings.UserName,
			Weight: null,
			WorkoutName: null,
			MostRecent: false
		};

		var title = '';

		var json = null;

		if (app.workout.workoutObj.ActivityType == 'random') {

			objectToPost.BodyPart = app.workout.workoutObj.randomExerciseObj.BodyPart;
			objectToPost.Type = 'exercise';
			objectToPost.ExerciseName = app.workout.workoutObj.randomExerciseObj.ExerciseName;

		}

		if (app.workout.workoutObj.ActivityType == 'workout') {

			objectToPost.BodyPart = app.workout.workoutObj.SelectedBodyPart;
			objectToPost.Type = 'workout';
			objectToPost.WorkoutName = app.workout.workoutObj.SelectedAction;

		}

		if (app.workout.workoutObj.ActivityType == 'exercise') {

			objectToPost.BodyPart = app.workout.workoutObj.SelectedBodyPart;
			objectToPost.ExerciseName = app.workout.workoutObj.SelectedAction;
			objectToPost.Type = 'exercise';
			objectToPost.WorkoutName = app.workout.workoutObj.SelectedAction;

		}

		if (app.workout.workoutObj.ActivityType == 'backalignment') {
			objectToPost.Type = 'Back Alignment';
		}

		if (app.workout.workoutObj.ActivityType == 'chestsqueezes') {
			objectToPost.Type = 'Chest / Arms Squeezee';
		}

		if (app.workout.workoutObj.ActivityType == 'jog') {
			objectToPost.Type = 'jog';
		}

		if (app.workout.workoutObj.ActivityType == 'resistancesmall') {
			objectToPost.Type = 'Resistance Cables (Sm)';
		}

		if (app.workout.workoutObj.ActivityType == 'resistancelarge') {
			objectToPost.Type = 'Resistance Cables (Lg)';
		}

		if (app.workout.workoutObj.ActivityType == 'stretch') {
			objectToPost.Type = 'Stretch';
		}

		app.ajaxPost('http://api.cognitivegenerationenterprises.com/api/physicalEntry', objectToPost, postPhysicalEntry_onSuccess, postPhysicalEntry_onError);

	});

	function postPhysicalEntry_onSuccess(response) {
		app.workout.workoutObj.PhysicalEntryId = response;
	}

	function postPhysicalEntry_onError(response) {
		console.log('Error Starting Workout: ' + response);
	}

	parent.set('endTimer', function (e) {

		$('.endTimer').css('display', 'none');

		app.endTimer();
		app.timer.timerObj.duration = finalDisplay;
		app.timer.timerObj.complete = true;

		if (app.workout.workoutObj.ActivityType == 'random') {
			app.mobileApp.navigate('modules/workout/workoutIndex.html');
		}

		if (app.workout.workoutObj.ActivityType == 'workout') {
			app.mobileApp.navigate('modules/workout/workoutIndex.html');
		}

		if (app.workout.workoutObj.ActivityType == 'exercise') {
			app.mobileApp.navigate('modules/workout/workoutIndex.html');
		}

		if (app.workout.workoutObj.ActivityType == 'backalignment') {
			app.physicalActivity.physicalActivityObj.complete = true;
			app.mobileApp.navigate('modules/workout/physicalActivityIndex.html');
		}

		if (app.workout.workoutObj.ActivityType == 'chestsqueezes') {
			app.physicalActivity.physicalActivityObj.complete = true;
			app.mobileApp.navigate('modules/workout/physicalActivityIndex.html');
		}

		if (app.workout.workoutObj.ActivityType == 'jog') {
			app.physicalActivity.physicalActivityObj.complete = true;
			app.mobileApp.navigate('modules/workout/physicalActivityIndex.html');
		}

		if (app.workout.workoutObj.ActivityType == 'resistancesmall') {
			app.physicalActivity.physicalActivityObj.complete = true;
			app.mobileApp.navigate('modules/workout/physicalActivityIndex.html');
		}

		if (app.workout.workoutObj.ActivityType == 'resistancelarge') {
			app.physicalActivity.physicalActivityObj.complete = true;
			app.mobileApp.navigate('modules/workout/physicalActivityIndex.html');
		}

		if (app.workout.workoutObj.ActivityType == 'stretch') {
			app.physicalActivity.physicalActivityObj.complete = true;
			app.mobileApp.navigate('modules/workout/physicalActivityIndex.html');
		}

	});

})(app.timer);

// END_CUSTOM_CODE_weighIn